#
# TABLE STRUCTURE FOR: bills
#

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `bill_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `due` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `tax_amount` int(11) NOT NULL,
  `diposit_amount` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('1', 'sampat', '8602442648', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:09:12');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('2', 'maze buildcon', '1111111111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:26:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('3', 'sayta', '1011111111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:28:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('4', 'sardar ji', '1234567011', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:30:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('5', 'gangotri ', '1200311111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:31:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('6', 'gaurav jain', '2222000002', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:32:21');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('7', 'desai ji', '3333333333', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:33:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('8', 'hebal som', '3333333331', 'khndwa road indore m.p', '2018-08-03', '0', '2018-08-03 10:41:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('9', 'singhl sahb', '1110000007', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:42:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('10', 'mukesh prajapat', '9827250327', 'indore m.p', '2018-08-03', '0', '2018-08-03 11:10:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('11', 'makhija ji', '5555555555', 'indore m.p', '2018-08-03', '0', '2018-08-03 11:15:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('12', 'natraj tiles', '6666666666', 'indore m.p', '2018-08-03', '0', '2018-08-03 14:26:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('13', 'badwani ji', '1000001112', 'khndwa road indore', '2018-08-07', '0', '2018-08-07 18:10:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('14', 'ultra tech', '4444440909', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:15:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('15', 'kukreja ji', '7070708888', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:19:17');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('16', 'jk buildcon', '1010101010', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:37:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('17', 'parsawnath ji', '8989898980', 'indore m.p', '2018-08-08', '0', '2018-08-08 10:33:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('18', 'jai baba', '7030500005', 'indore m.p', '2018-08-08', '0', '2018-08-08 10:39:53');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('19', 'ML AGARWAL SCHOOL', '6565656565', 'INDORE MP', '2018-08-08', '0', '2018-08-08 16:06:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('20', 'kapil pariya', '5050505060', 'indore mp', '2018-08-08', '0', '2018-08-08 16:09:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('21', 'capital', '7676767687', 'brg indore', '2018-08-13', '0', '2018-08-13 11:50:57');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('22', 'umriya bricks factory', '5454545454', 'indore umriya', '2018-08-18', '0', '2018-08-18 11:32:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('23', 'D S', '1010203030', 'INDORE M.P', '2018-09-01', '0', '2018-09-01 11:36:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('24', 'RM', '9999999998', 'INDORE', '2018-09-01', '0', '2018-09-01 11:44:47');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('25', 'ARJUN JAT', '2222111134', 'INDORE', '2018-09-01', '0', '2018-09-01 11:46:57');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('26', 'PANKAJ MAKHIJA', '9898765432', 'INDORE', '2018-09-01', '0', '2018-09-01 11:49:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('27', 'SHER SINGH', '1212121234', 'INDORE', '2018-09-01', '0', '2018-09-01 11:51:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('28', '892', '8787690901', 'INDORE', '2018-09-01', '0', '2018-09-01 11:55:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('29', 'BANTY RAWLIYA', '3456783490', 'INDORE', '2018-09-01', '0', '2018-09-01 11:56:35');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('30', 'CASH', '0909090909', 'INDORE', '2018-09-01', '0', '2018-09-01 12:07:33');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('31', 'PL', '1212347890', 'INDORE', '2018-09-01', '0', '2018-09-01 12:20:37');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('32', 'ms', '4563217890', 'indore', '2018-09-01', '0', '2018-09-01 16:38:45');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('33', 'CHNDU', '9898765431', 'INDORE', '2018-09-01', '0', '2018-09-01 16:57:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('34', 'narendra khndwal', '6767890564', 'indore', '2018-09-02', '0', '2018-09-02 11:45:55');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('35', 'KAPIL PARIYA 8 MIL', '2323456781', 'INDORE', '2018-09-02', '0', '2018-09-02 12:16:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('36', 'sanny jat', '8787906547', 'indore', '2018-09-03', '0', '2018-09-03 12:11:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('37', 'RAHUL', '9807654321', 'INDORE', '2018-09-03', '0', '2018-09-03 12:28:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('38', 'SEWAK RAM', '8888899999', 'INDORE', '2018-09-03', '0', '2018-09-03 12:32:24');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('39', 'lakhn jat', '0909090901', 'indore', '2018-09-06', '0', '2018-09-06 14:55:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('40', 'sunil sheth', '4545678632', 'indore', '2018-09-06', '0', '2018-09-06 15:06:22');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('41', 'MAHESH PATIDAR', '8976543214', 'INDORE', '2018-09-11', '0', '2018-09-11 12:42:00');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('42', 'goyal sahab', '5678432103', 'indore mp', '2018-09-15', '0', '2018-09-15 15:24:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('43', 'mangesh yadav', '9080706054', 'indore mp', '2018-09-18', '0', '2018-09-18 14:46:58');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('44', 'shiv ram', '6070805432', 'indore mp', '2018-09-21', '0', '2018-09-21 09:38:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('45', 'sanjay khndewal', '9712309875', 'indore', '2018-09-29', '0', '2018-09-29 15:52:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('46', 'pahuja ji 8 mil', '9087654321', 'INDORE', '2018-09-30', '0', '2018-10-01 15:14:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('47', 'Lokesh ji ', '1029304059', 'indore mp', '2018-10-01', '0', '2018-10-01 15:30:10');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('48', 'Trilok poltri farm', '3040501065', 'indore mp', '2018-10-01', '0', '2018-10-01 15:44:03');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('49', 'DARWAR', '8123123456', 'INDORE', '2018-10-07', '0', '2018-10-07 15:14:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('50', 'MONU ARORA', '2134333333', 'INDORE', '2018-10-07', '0', '2018-10-07 15:40:45');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('51', 'manu arora', '9870984563', 'indore', '2018-10-12', '0', '2018-10-12 09:48:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('52', 'rajesh agarwal', '9870004423', 'indore', '2018-10-29', '0', '2018-10-29 12:16:55');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('53', 'bheem darwar', '6060789045', 'indore', '2018-10-29', '0', '2018-10-29 12:29:00');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('54', 'RAJESH AGARWAL', '7098009987', 'INDORE', '2018-11-05', '1', '2018-11-05 10:57:33');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('55', 'yadav ji bambe  hospital', '5123098645', 'indore', '2018-11-14', '0', '2018-11-14 16:14:31');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('56', 'UJJAWAL KHURANA', '8933445567', 'INDORE', '2018-11-18', '0', '2018-11-18 15:48:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('57', 'kishor chudhry', '9888977765', 'indore', '2018-11-20', '0', '2018-11-20 14:52:44');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('58', 'jeevan', '9876678954', 'indore', '2018-11-22', '0', '2018-11-22 16:34:09');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('59', 'syam agarwal', '8763355123', 'indore', '2018-12-06', '0', '2018-12-06 12:21:31');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('60', 'rajendra renuka dhaba', '4563289990', 'indore', '2018-12-10', '0', '2018-12-10 15:42:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('61', 'sunita jagdis khndelwal', '2233445500', 'indore', '2018-12-15', '0', '2018-12-15 14:54:46');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('62', 'rajesh jindal', '5674399876', 'indore', '2018-12-17', '0', '2018-12-17 16:47:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('63', 'vijay agarwal', '9876543290', 'indore', '2018-12-17', '0', '2018-12-17 16:51:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('64', 'omaxe city', '4456789033', 'indore', '2018-12-22', '0', '2018-12-22 16:33:32');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('65', 'DPS', '8765431234', 'INDORE', '2018-12-23', '0', '2018-12-23 15:00:54');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('66', 'amit aary', '3330098776', 'indore', '2018-12-28', '0', '2018-12-28 13:30:01');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('67', 'harsh agarwal', '1123456789', 'indore', '2018-12-28', '0', '2018-12-28 16:55:26');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('68', 'mohit and company', '4321111222', 'indore', '2018-12-29', '0', '2018-12-29 15:22:44');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('69', 'mhadev tiles', '1112345635', 'indore', '2018-12-30', '0', '2018-12-30 16:38:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('70', 'mahadev tiles', '1123433491', 'indore', '2018-12-30', '0', '2018-12-30 16:40:22');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('71', 'MALWA COLLAGE SURENDRA JI', '1102345634', 'INDORE', '2019-01-02', '0', '2019-01-02 15:33:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('72', 'SANTOSH BY PASS', '2134521342', 'INDORE', '2019-01-02', '0', '2019-01-02 15:44:03');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('73', 'jethanand', '9098765439', 'indore', '2019-01-04', '0', '2019-01-04 10:10:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('74', 'kumawat ji', '1112223321', 'indore', '2019-01-12', '0', '2019-01-12 17:02:41');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('75', 'kasturiya ji', '9807654366', 'indore', '2019-01-12', '0', '2019-01-12 17:10:29');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('76', 'jai mata di', '1234123345', 'indore', '2019-02-02', '0', '2019-02-02 16:11:35');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('77', 'stp jk', '0909090902', 'indore', '2019-02-09', '0', '2019-02-09 16:19:05');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('78', 'manish pandit', '3322114556', 'indore', '2019-03-09', '0', '2019-03-09 17:32:10');


#
# TABLE STRUCTURE FOR: dues
#

DROP TABLE IF EXISTS `dues`;

CREATE TABLE `dues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: gate_pass
#

DROP TABLE IF EXISTS `gate_pass`;

CREATE TABLE `gate_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` varchar(250) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `client_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=latin1;

INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('1', '994', '2019-03-15', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '0', '', '2019-03-15', '2019-03-15 14:15:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('2', '995', '2019-03-15', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:15:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('3', '996', '2019-03-15', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '0', '', '2019-03-15', '2019-03-15 14:16:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('4', '997', '2019-03-15', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:16:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('5', '998', '2019-03-15', '00:00 AM', '00:00 AM', '20', '60', '1', '9', '0', '', '2019-03-15', '2019-03-15 14:17:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('6', '999', '2019-03-15', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-03-15', '2019-03-15 14:17:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('7', '1000', '2019-03-15', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:18:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('8', '1', '2019-03-15', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-03-15', '2019-03-15 14:20:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('9', '2', '2019-03-15', '00:00 AM', '00:00 AM', '4', '158', '2', '10', '0', '', '2019-03-15', '2019-03-15 14:20:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('10', '3', '2019-03-15', '00:00 AM', '00:00 AM', '53', '121', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:21:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('11', '4', '2019-03-15', '00:00 AM', '00:00 AM', '29', '38', '2', '4', '0', '', '2019-03-15', '2019-03-15 14:22:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('12', '5', '2019-03-15', '00:00 AM', '00:00 AM', '4', '158', '3', '10', '0', '', '2019-03-15', '2019-03-15 14:23:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('13', '6', '2019-03-15', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-15', '2019-03-15 14:24:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('14', '7', '2019-03-15', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '0', '', '2019-03-15', '2019-03-15 14:24:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('15', '8', '2019-03-15', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-15', '2019-03-15 14:25:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('16', '9', '2019-03-15', '00:00 AM', '00:00 AM', '23', '49', '3', '9', '0', '', '2019-03-15', '2019-03-15 14:25:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('17', '10', '2019-03-15', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:26:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('18', '11', '2019-03-15', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:26:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('19', '12', '2019-03-15', '00:00 AM', '00:00 AM', '25', '46', '1', '9', '0', '', '2019-03-15', '2019-03-15 14:27:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('20', '13', '2019-03-15', '00:00 AM', '00:00 AM', '53', '121', '3', '4', '0', '', '2019-03-15', '2019-03-15 14:27:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('21', '14', '2019-03-15', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:28:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('22', '16', '2019-03-15', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-15', '2019-03-15 14:28:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('23', '17', '2019-03-15', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-03-15', '2019-03-15 14:29:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('24', '15', '2019-03-15', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-03-16', '2019-03-16 15:34:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('25', '18', '2019-03-15', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-16', '2019-03-16 15:35:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('26', '19', '2019-03-15', '00:00 AM', '00:00 AM', '38', '57', '1', '9', '0', '', '2019-03-16', '2019-03-16 15:35:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('27', '20', '2019-03-15', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-03-16', '2019-03-16 15:36:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('28', '21', '2019-03-15', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-03-16', '2019-03-16 15:37:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('29', '22', '2019-03-15', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-16', '2019-03-16 15:37:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('30', '23', '2019-03-15', '00:00 AM', '00:00 AM', '53', '119', '3', '10', '0', '', '2019-03-16', '2019-03-16 15:39:39');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('31', '24', '2019-03-15', '00:00 AM', '00:00 AM', '30', '40', '3', '3', '0', '', '2019-03-16', '2019-03-16 15:40:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('32', '25', '2019-03-15', '00:00 AM', '00:00 AM', '2', '186', '1', '9', '0', '', '2019-03-16', '2019-03-16 15:41:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('33', '26', '2019-03-15', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '0', '', '2019-03-16', '2019-03-16 15:41:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('34', '27', '2019-03-16', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-03-16', '2019-03-16 15:42:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('35', '28', '2019-03-16', '00:00 AM', '00:00 AM', '23', '208', '9', '9', '0', '', '2019-03-16', '2019-03-16 15:51:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('36', '29', '2019-03-16', '00:00 AM', '00:00 AM', '23', '209', '9', '9', '0', '', '2019-03-16', '2019-03-16 15:52:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('37', '30', '2019-03-16', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-03-16', '2019-03-16 15:53:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('38', '31', '2019-03-16', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-03-16', '2019-03-16 15:53:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('39', '32', '2019-03-16', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:07:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('40', '33', '2019-03-16', '00:00 AM', '00:00 AM', '6', '160', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:07:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('41', '34', '2019-03-16', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:08:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('42', '35', '2019-03-16', '00:00 AM', '00:00 AM', '36', '55', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:08:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('43', '36', '2019-03-16', '00:00 AM', '00:00 AM', '53', '119', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:09:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('44', '37', '2019-03-16', '00:00 AM', '00:00 AM', '38', '57', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:10:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('45', '38', '2019-03-16', '00:00 AM', '00:00 AM', '11', '161', '3', '10', '0', '', '2019-03-16', '2019-03-16 16:10:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('46', '39', '2019-03-16', '00:00 AM', '00:00 AM', '26', '50', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:11:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('47', '40', '2019-03-16', '00:00 AM', '00:00 AM', '36', '55', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:11:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('48', '41', '2019-03-16', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:12:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('49', '42', '2019-03-16', '00:00 AM', '00:00 AM', '46', '144', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:13:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('50', '43', '2019-03-16', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:13:31');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('51', '44', '2019-03-16', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:13:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('52', '45', '2019-03-16', '00:00 AM', '00:00 AM', '29', '38', '2', '4', '0', '', '2019-03-16', '2019-03-16 16:14:39');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('53', '46', '2019-03-16', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:15:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('54', '47', '2019-03-16', '00:00 AM', '00:00 AM', '26', '50', '3', '9', '0', '', '2019-03-16', '2019-03-16 16:16:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('55', '48', '2019-03-16', '00:00 AM', '00:00 AM', '11', '161', '7', '10', '0', '', '2019-03-16', '2019-03-16 16:17:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('56', '49', '2019-03-16', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:17:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('57', '50', '2019-03-16', '00:00 AM', '00:00 AM', '23', '32', '2', '4', '0', '', '2019-03-16', '2019-03-16 16:18:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('58', '51', '2019-03-16', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:18:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('59', '52', '2019-03-16', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:19:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('60', '53', '2019-03-16', '00:00 AM', '00:00 AM', '4', '158', '3', '10', '0', '', '2019-03-16', '2019-03-16 16:21:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('61', '54', '2019-03-16', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:22:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('62', '55', '2019-03-16', '00:00 AM', '00:00 AM', '53', '121', '3', '4', '0', '', '2019-03-16', '2019-03-16 16:24:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('63', '56', '2019-03-16', '00:00 AM', '00:00 AM', '26', '64', '3', '9', '0', '', '2019-03-16', '2019-03-16 16:24:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('64', '57', '2019-03-16', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:25:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('65', '58', '2019-03-16', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-03-16', '2019-03-16 16:25:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('66', '59', '2019-03-16', '00:00 AM', '00:00 AM', '24', '45', '3', '9', '0', '', '2019-03-16', '2019-03-16 16:26:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('67', '60', '2019-03-16', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-03-16', '2019-03-16 16:26:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('68', '61', '2019-03-16', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-03-16', '2019-03-16 16:27:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('69', '62', '2019-03-16', '00:00 AM', '00:00 AM', '46', '144', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:27:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('70', '63', '2019-03-16', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-03-16', '2019-03-16 16:28:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('71', '837', '2019-03-10', '00:00 AM', '00:00 AM', '52', '120', '7', '20', '0', '', '2019-03-16', '2019-03-16 16:34:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('72', '845', '2019-03-10', '00:00 AM', '00:00 AM', '52', '120', '7', '20', '0', '', '2019-03-16', '2019-03-16 16:34:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('73', '809', '2019-03-09', '00:00 AM', '00:00 AM', '43', '83', '8', '20', '0', '', '2019-03-16', '2019-03-16 16:37:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('74', '831', '2019-03-10', '00:00 AM', '00:00 AM', '43', '83', '8', '20', '0', '', '2019-03-16', '2019-03-16 16:38:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('75', '832', '2019-03-10', '00:00 AM', '00:00 AM', '43', '169', '1', '20', '0', '', '2019-03-16', '2019-03-16 16:39:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('76', '842', '2019-03-10', '00:00 AM', '00:00 AM', '43', '83', '3', '20', '0', '', '2019-03-16', '2019-03-16 16:39:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('77', '577', '2019-03-01', '00:00 AM', '00:00 AM', '34', '48', '3', '9', '0', '', '2019-03-16', '2019-03-16 16:41:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('78', '707', '2019-03-07', '00:00 AM', '00:00 AM', '34', '48', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:41:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('79', '720', '2019-03-07', '00:00 AM', '00:00 AM', '34', '48', '1', '9', '0', '', '2019-03-16', '2019-03-16 16:42:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('80', '64', '2019-03-16', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-17', '2019-03-17 11:53:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('81', '65', '2019-03-16', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-03-17', '2019-03-17 11:54:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('82', '66', '2019-03-16', '00:00 AM', '00:00 AM', '46', '144', '1', '10', '0', '', '2019-03-17', '2019-03-17 11:54:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('83', '67', '2019-03-16', '00:00 AM', '00:00 AM', '58', '141', '1', '5', '0', '', '2019-03-17', '2019-03-17 11:55:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('84', '68', '2019-03-16', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-03-17', '2019-03-17 11:56:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('85', '69', '2019-03-16', '00:00 AM', '00:00 AM', '26', '64', '1', '10', '0', '', '2019-03-17', '2019-03-17 11:56:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('86', '70', '2019-03-16', '00:00 AM', '00:00 AM', '26', '78', '1', '10', '0', '', '2019-03-17', '2019-03-17 11:57:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('87', '71', '2019-03-16', '00:00 AM', '00:00 AM', '46', '144', '1', '10', '0', '', '2019-03-17', '2019-03-17 12:00:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('88', '72', '2019-03-16', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-17', '2019-03-17 12:05:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('89', '73', '2019-03-16', '00:00 AM', '00:00 AM', '11', '161', '3', '10', '0', '', '2019-03-17', '2019-03-17 12:06:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('90', '74', '2019-03-16', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-03-17', '2019-03-17 12:06:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('91', '75', '2019-03-16', '00:00 AM', '00:00 AM', '53', '119', '1', '10', '0', '', '2019-03-17', '2019-03-17 12:07:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('92', '76', '2019-03-16', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-03-17', '2019-03-17 12:08:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('93', '77', '2019-03-16', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2019-03-17', '2019-03-17 12:08:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('94', '78', '2019-03-16', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-03-17', '2019-03-17 12:09:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('95', '79', '2019-03-16', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2019-03-17', '2019-03-17 12:09:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('96', '80', '2019-03-16', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2019-03-17', '2019-03-17 12:10:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('97', '81', '2019-03-16', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2019-03-17', '2019-03-17 12:10:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('98', '83', '2019-03-17', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-03-17', '2019-03-17 12:11:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('99', '84', '2019-03-17', '00:00 AM', '00:00 AM', '23', '209', '9', '9', '0', '', '2019-03-17', '2019-03-17 12:12:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('100', '85', '2019-03-17', '00:00 AM', '00:00 AM', '4', '4', '3', '22', '0', '', '2019-03-17', '2019-03-17 12:13:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('101', '86', '2019-03-17', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-17', '2019-03-17 13:03:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('102', '87', '2019-03-17', '00:00 AM', '00:00 AM', '36', '55', '1', '9', '0', '', '2019-03-17', '2019-03-17 13:19:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('103', '88', '2019-03-17', '00:00 AM', '00:00 AM', '24', '45', '3', '9', '0', '', '2019-03-17', '2019-03-17 13:20:09');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('104', '89', '2019-03-17', '00:00 AM', '00:00 AM', '4', '158', '2', '10', '0', '', '2019-03-17', '2019-03-17 13:20:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('105', '90', '2019-03-17', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2019-03-17', '2019-03-17 13:21:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('106', '91', '2019-03-17', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-17', '2019-03-17 14:56:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('107', '92', '2019-03-17', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-03-17', '2019-03-17 14:57:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('108', '93', '2019-03-17', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-03-17', '2019-03-17 14:57:42');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('109', '94', '2019-03-17', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-17', '2019-03-17 14:58:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('110', '95', '2019-03-17', '00:00 AM', '00:00 AM', '16', '16', '3', '22', '0', '', '2019-03-17', '2019-03-17 14:58:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('111', '96', '2019-03-17', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '0', '', '2019-03-17', '2019-03-17 14:59:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('112', '97', '2019-03-17', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-03-17', '2019-03-17 14:59:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('113', '98', '2019-03-17', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-03-17', '2019-03-17 15:00:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('114', '99', '2019-03-17', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '0', '', '2019-03-17', '2019-03-17 15:00:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('115', '100', '2019-03-17', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-03-17', '2019-03-17 15:01:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('116', '101', '2019-03-17', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-03-17', '2019-03-17 15:01:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('117', '102', '2019-03-17', '00:00 AM', '00:00 AM', '63', '153', '1', '22', '0', '', '2019-03-17', '2019-03-17 15:02:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('118', '103', '2019-03-17', '00:00 AM', '00:00 AM', '11', '161', '7', '10', '0', '', '2019-03-17', '2019-03-17 15:02:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('119', '104', '2019-03-17', '00:00 AM', '00:00 AM', '26', '54', '1', '9', '0', '', '2019-03-17', '2019-03-17 15:03:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('120', '105', '2019-03-17', '00:00 AM', '00:00 AM', '26', '64', '1', '9', '0', '', '2019-03-17', '2019-03-17 15:03:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('121', '106', '2019-03-17', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-17', '2019-03-17 15:04:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('122', '107', '2019-03-17', '00:00 AM', '00:00 AM', '46', '144', '1', '10', '0', '', '2019-03-17', '2019-03-17 15:04:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('123', '108', '2019-03-17', '00:00 AM', '00:00 AM', '63', '153', '1', '22', '0', '', '2019-03-17', '2019-03-17 15:05:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('124', '790', '2019-03-09', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:43:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('125', '802', '2019-03-09', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:44:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('126', '812', '2019-03-09', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:45:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('127', '827', '2019-03-10', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:46:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('128', '829', '2019-03-10', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-03-17', '2019-03-17 16:46:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('129', '839', '2019-03-10', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:47:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('130', '854', '2019-03-10', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:48:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('131', '861', '2019-03-11', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-17', '2019-03-17 16:48:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('132', '863', '2019-03-11', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:49:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('133', '976', '2019-03-14', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-03-17', '2019-03-17 16:50:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('134', '579', '2019-03-01', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:08:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('135', '581', '2019-03-01', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:09:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('136', '612', '2019-03-02', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:10:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('137', '617', '2019-03-02', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-17', '2019-03-17 17:10:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('138', '650', '2019-03-03', '00:00 AM', '00:00 AM', '32', '43', '3', '10', '0', '', '2019-03-17', '2019-03-17 17:12:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('139', '653', '2019-03-03', '00:00 AM', '00:00 AM', '32', '44', '1', '9', '0', '', '2019-03-17', '2019-03-17 17:13:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('140', '690', '2019-03-05', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:14:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('141', '704', '2019-03-07', '00:00 AM', '00:00 AM', '32', '43', '7', '10', '0', '', '2019-03-17', '2019-03-17 17:15:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('142', '711', '2019-03-07', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-17', '2019-03-17 17:16:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('143', '732', '2019-03-08', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:16:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('144', '736', '2019-03-08', '00:00 AM', '00:00 AM', '32', '44', '3', '10', '0', '', '2019-03-17', '2019-03-17 17:17:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('145', '784', '2019-03-09', '00:00 AM', '00:00 AM', '32', '43', '7', '9', '0', '', '2019-03-17', '2019-03-17 17:19:09');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('146', '796', '2019-03-09', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:19:42');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('147', '828', '2019-03-10', '00:00 AM', '00:00 AM', '32', '44', '3', '10', '0', '', '2019-03-17', '2019-03-17 17:20:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('148', '833', '2019-03-10', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-17', '2019-03-17 17:20:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('149', '836', '2019-03-10', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-17', '2019-03-17 17:21:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('150', '867', '2019-03-11', '00:00 AM', '00:00 AM', '32', '43', '7', '9', '0', '', '2019-03-17', '2019-03-17 17:22:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('151', '868', '2019-03-11', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '0', '', '2019-03-17', '2019-03-17 17:22:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('152', '109', '2019-03-17', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-03-18', '2019-03-18 11:00:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('153', '110', '2019-03-17', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-18', '2019-03-18 11:01:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('154', '111', '2019-03-17', '00:00 AM', '00:00 AM', '13', '28', '1', '22', '0', '', '2019-03-18', '2019-03-18 11:02:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('155', '112', '2019-03-17', '00:00 AM', '00:00 AM', '11', '161', '3', '10', '0', '', '2019-03-18', '2019-03-18 11:03:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('156', '113', '2019-03-17', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:04:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('157', '115', '2019-03-17', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-18', '2019-03-18 11:04:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('158', '116', '2019-03-17', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-18', '2019-03-18 11:05:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('159', '117', '2019-03-17', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-03-18', '2019-03-18 11:05:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('160', '118', '2019-03-17', '00:00 AM', '00:00 AM', '58', '141', '3', '4', '0', '', '2019-03-18', '2019-03-18 11:06:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('161', '119', '2019-03-17', '00:00 AM', '00:00 AM', '11', '11', '7', '16', '0', '', '2019-03-18', '2019-03-18 11:07:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('162', '120', '2019-03-17', '00:00 AM', '00:00 AM', '13', '28', '1', '22', '0', '', '2019-03-18', '2019-03-18 11:08:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('163', '121', '2019-03-18', '00:00 AM', '00:00 AM', '36', '55', '1', '9', '0', '', '2019-03-18', '2019-03-18 11:08:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('164', '122', '2019-03-18', '00:00 AM', '00:00 AM', '4', '158', '2', '10', '0', '', '2019-03-18', '2019-03-18 11:09:09');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('165', '123', '2019-03-18', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-03-18', '2019-03-18 11:09:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('166', '124', '2019-03-18', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:10:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('167', '125', '2019-03-18', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-18', '2019-03-18 11:10:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('168', '126', '2019-03-18', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-03-18', '2019-03-18 11:11:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('169', '872', '2019-03-11', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-18', '2019-03-18 11:13:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('170', '893', '2019-03-12', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:14:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('171', '895', '2019-03-12', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '0', '', '2019-03-18', '2019-03-18 11:15:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('172', '927', '2019-03-13', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-18', '2019-03-18 11:16:10');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('173', '929', '2019-03-13', '00:00 AM', '00:00 AM', '32', '44', '3', '10', '0', '', '2019-03-18', '2019-03-18 11:17:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('174', '942', '2019-03-13', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:17:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('175', '950', '2019-03-13', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-03-18', '2019-03-18 11:18:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('176', '954', '2019-03-13', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:18:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('177', '958', '2019-03-13', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:19:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('178', '973', '2019-03-14', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-03-18', '2019-03-18 11:19:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('179', '127', '2019-03-18', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-03-18', '2019-03-18 16:21:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('180', '128', '2019-03-18', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-03-18', '2019-03-18 16:21:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('181', '129', '2019-03-18', '00:00 AM', '00:00 AM', '10', '151', '3', '10', '0', '', '2019-03-18', '2019-03-18 16:22:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('182', '130', '2019-03-18', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '0', '', '2019-03-18', '2019-03-18 16:23:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('183', '131', '2019-03-18', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:23:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('184', '132', '2019-03-18', '00:00 AM', '00:00 AM', '53', '119', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:24:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('185', '133', '2019-03-18', '00:00 AM', '00:00 AM', '38', '128', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:24:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('186', '134', '2019-03-18', '00:00 AM', '00:00 AM', '26', '54', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:25:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('187', '135', '2019-03-18', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-03-18', '2019-03-18 16:25:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('188', '136', '2019-03-18', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '0', '', '2019-03-18', '2019-03-18 16:26:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('189', '137', '2019-03-18', '00:00 AM', '00:00 AM', '26', '78', '1', '12', '0', '', '2019-03-18', '2019-03-18 16:26:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('190', '138', '2019-03-18', '00:00 AM', '00:00 AM', '26', '36', '1', '10', '0', '', '2019-03-18', '2019-03-18 16:27:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('191', '139', '2019-03-18', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-18', '2019-03-18 16:29:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('192', '140', '2019-03-18', '00:00 AM', '00:00 AM', '36', '55', '1', '10', '0', '', '2019-03-18', '2019-03-18 16:31:09');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('193', '141', '2019-03-18', '00:00 AM', '00:00 AM', '53', '119', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:31:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('194', '142', '2019-03-18', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:33:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('195', '143', '2019-03-18', '00:00 AM', '00:00 AM', '26', '64', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:33:42');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('196', '144', '2019-03-18', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-03-18', '2019-03-18 16:34:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('197', '145', '2019-03-18', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-03-18', '2019-03-18 16:34:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('198', '146', '2019-03-18', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-03-18', '2019-03-18 16:35:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('199', '147', '2019-03-18', '00:00 AM', '00:00 AM', '58', '141', '3', '4', '0', '', '2019-03-18', '2019-03-18 16:35:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('200', '148', '2019-03-18', '00:00 AM', '00:00 AM', '26', '78', '1', '12', '0', '', '2019-03-18', '2019-03-18 16:36:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('201', '149', '2019-03-18', '00:00 AM', '00:00 AM', '26', '36', '1', '10', '0', '', '2019-03-18', '2019-03-18 16:36:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('202', '150', '2019-03-18', '00:00 AM', '00:00 AM', '53', '119', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:37:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('203', '151', '2019-03-18', '00:00 AM', '00:00 AM', '27', '37', '1', '22', '0', '', '2019-03-18', '2019-03-18 16:39:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('204', '152', '2019-03-18', '00:00 AM', '00:00 AM', '26', '39', '1', '17', '0', '', '2019-03-18', '2019-03-18 16:40:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('205', '153', '2019-03-18', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '0', '', '2019-03-18', '2019-03-18 16:40:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('206', '154', '2019-03-18', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-03-19', '2019-03-19 12:25:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('207', '155', '2019-03-18', '00:00 AM', '00:00 AM', '6', '6', '3', '22', '0', '', '2019-03-19', '2019-03-19 12:25:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('208', '156', '2019-03-18', '00:00 AM', '00:00 AM', '53', '119', '1', '10', '0', '', '2019-03-19', '2019-03-19 12:26:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('209', '157', '2019-03-18', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-19', '2019-03-19 12:26:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('210', '158', '2019-03-18', '00:00 AM', '00:00 AM', '58', '141', '3', '4', '0', '', '2019-03-19', '2019-03-19 12:27:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('211', '159', '2019-03-18', '00:00 AM', '00:00 AM', '26', '36', '1', '9', '0', '', '2019-03-19', '2019-03-19 12:28:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('212', '160', '2019-03-18', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-19', '2019-03-19 12:28:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('213', '161', '2019-03-18', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2019-03-19', '2019-03-19 12:29:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('214', '162', '2019-03-19', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-03-19', '2019-03-19 12:29:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('215', '163', '2019-03-19', '00:00 AM', '00:00 AM', '20', '60', '1', '9', '0', '', '2019-03-19', '2019-03-19 12:30:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('216', '164', '2019-03-19', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '0', '', '2019-03-19', '2019-03-19 12:30:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('217', '165', '2019-03-19', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-03-19', '2019-03-19 12:31:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('218', '166', '2019-03-19', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-03-19', '2019-03-19 12:31:55');


#
# TABLE STRUCTURE FOR: materials
#

DROP TABLE IF EXISTS `materials`;

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('1', '20 MM', '2018-07-24', '0', '2018-07-31 22:55:28');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('2', '10 MM', '2018-07-24', '0', '2018-07-31 22:55:19');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('3', '6 MM', '2018-07-24', '0', '2018-07-31 22:55:10');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('4', '3 shoot', '2018-07-24', '0', '2018-07-31 22:55:43');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('5', 'Dhoola', '2018-07-24', '0', '2018-07-31 22:56:47');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('6', 'M Send', '2018-07-28', '0', '2018-07-31 22:57:00');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('7', 'Reti', '2018-07-28', '0', '2018-07-31 22:57:11');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('8', '40 mm', '2018-09-18', '0', '2018-09-18 14:51:35');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('9', 'GSB', '2018-10-12', '0', '2018-10-12 17:07:39');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `email`, `password`, `role`, `created_date`, `name`, `mobile_no`, `description`, `entry_date`) VALUES ('1', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2018-07-22 14:41:58', 'Admin', '9098343935', '', '2018-07-20');


#
# TABLE STRUCTURE FOR: vehicles
#

DROP TABLE IF EXISTS `vehicles`;

CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vehicle_no` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=latin1;

INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('1', '1', '0324', '2018-08-03', '0', '2018-08-12 12:55:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('2', '2', '0324', '2018-08-03', '0', '2018-08-12 12:56:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('3', '3', '0324', '2018-08-03', '0', '2018-08-12 12:56:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('4', '4', '0324', '2018-08-03', '0', '2018-08-12 12:56:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('5', '5', '0324', '2018-08-03', '0', '2018-08-12 12:56:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('6', '6', '0324', '2018-08-03', '0', '2018-08-12 12:57:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('7', '7', '0324', '2018-08-03', '0', '2018-08-12 12:57:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('8', '8', '0324', '2018-08-03', '0', '2018-08-12 12:57:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('9', '9', '0324', '2018-08-03', '0', '2018-08-12 12:57:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('10', '10', '0324', '2018-08-03', '0', '2018-08-12 12:57:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('11', '11', '0324', '2018-08-03', '0', '2018-08-12 12:55:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('12', '12', '0324', '2018-08-03', '0', '2018-08-12 12:58:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('13', '13', '324', '2018-08-07', '0', '2018-08-07 18:10:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('14', '14', '0324', '2018-08-07', '0', '2018-08-07 18:15:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('15', '15', '0324', '2018-08-07', '0', '2018-08-07 18:19:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('16', '16', '0324', '2018-08-07', '0', '2018-08-07 18:38:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('17', '17', '0324', '2018-08-08', '0', '2018-08-08 10:33:35');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('18', '18', '0324', '2018-08-08', '0', '2018-08-08 10:40:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('19', '19', '0324', '2018-08-08', '0', '2018-08-08 16:07:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('20', '20', '0324', '2018-08-08', '0', '2018-08-08 16:09:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('21', '21', '3510', '2018-08-13', '0', '2018-08-13 11:51:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('22', '21', '0324', '2018-08-13', '0', '2018-08-13 11:51:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('23', '6', '6089', '2018-08-13', '0', '2018-08-13 12:01:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('24', '9', '0576', '2018-08-14', '0', '2018-08-14 11:11:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('25', '4', '9705', '2018-08-14', '0', '2018-08-14 11:13:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('26', '20', '9705', '2018-08-14', '0', '2018-08-14 11:16:46');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('27', '20', '3510', '2018-08-14', '0', '2018-08-14 11:17:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('28', '13', '0324', '2018-08-18', '0', '2018-08-18 10:48:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('29', '22', '0324', '2018-08-18', '0', '2018-08-18 11:32:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('30', '11', '4233', '2018-08-20', '0', '2018-08-20 14:34:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('31', '4', '0825', '2018-08-30', '0', '2018-08-30 16:19:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('32', '23', '1463', '2018-09-01', '0', '2018-09-01 11:37:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('33', '23', '8887', '2018-09-01', '0', '2018-09-01 11:39:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('34', '24', '0825', '2018-09-01', '0', '2018-09-01 11:45:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('35', '25', '4683', '2018-09-01', '0', '2018-09-01 11:47:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('36', '26', '1543', '2018-09-01', '0', '2018-09-01 11:49:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('37', '27', '2253', '2018-09-01', '0', '2018-09-01 11:52:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('38', '29', '3716', '2018-09-01', '0', '2018-09-01 11:56:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('39', '26', '2641', '2018-09-01', '0', '2018-09-01 12:00:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('40', '30', 'TRALI', '2018-09-01', '0', '2018-09-01 12:08:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('41', '23', '0221', '2018-09-01', '0', '2018-09-01 12:12:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('42', '31', '6089', '2018-09-01', '0', '2018-09-01 12:21:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('43', '32', '7238', '2018-09-01', '0', '2018-09-01 16:39:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('44', '32', '9705', '2018-09-01', '0', '2018-09-01 16:39:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('45', '24', '4233', '2018-09-01', '0', '2018-09-01 16:41:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('46', '25', '7707', '2018-09-01', '0', '2018-09-01 16:44:21');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('47', '33', '0207', '2018-09-01', '0', '2018-09-01 16:57:27');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('48', '34', '8669', '2018-09-02', '0', '2018-09-02 11:46:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('49', '23', '1251', '2018-09-02', '0', '2018-09-02 11:53:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('50', '26', '2103', '2018-09-02', '0', '2018-09-02 11:54:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('51', '26', '1752', '2018-09-02', '0', '2018-09-02 11:56:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('52', '35', '3510', '2018-09-02', '0', '2018-09-02 12:16:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('53', '35', '0324', '2018-09-02', '0', '2018-09-02 12:16:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('54', '26', '0809', '2018-09-02', '0', '2018-09-02 12:30:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('55', '36', '4311', '2018-09-03', '0', '2018-09-03 12:12:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('56', '37', '1783', '2018-09-03', '0', '2018-09-03 12:28:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('57', '38', '1385', '2018-09-03', '0', '2018-09-03 12:32:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('58', '39', 'trali', '2018-09-06', '0', '2018-09-06 14:56:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('59', '40', '3510', '2018-09-06', '0', '2018-09-06 15:06:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('60', '20', '6631', '2018-09-07', '0', '2018-09-07 14:47:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('61', '30', '9111', '2018-09-07', '0', '2018-09-07 15:42:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('62', '38', '6199', '2018-09-07', '0', '2018-09-07 15:45:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('63', '32', '0825', '2018-09-07', '0', '2018-09-07 15:53:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('64', '26', '0230', '2018-09-08', '0', '2018-09-08 15:50:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('65', '6', '576', '2018-09-10', '0', '2018-09-10 12:57:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('66', '11', '0576', '2018-09-10', '0', '2018-09-10 13:04:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('67', '11', '6089', '2018-09-10', '0', '2018-09-10 13:06:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('68', '15', '0576', '2018-09-10', '0', '2018-09-10 13:07:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('69', '15', '6089', '2018-09-10', '0', '2018-09-10 13:08:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('70', '17', '0825', '2018-09-11', '0', '2018-09-11 12:16:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('71', '30', '5106', '2018-09-11', '0', '2018-09-11 12:20:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('72', '32', '3716', '2018-09-11', '0', '2018-09-11 12:25:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('73', '30', '0834', '2018-09-11', '0', '2018-09-11 12:39:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('74', '41', '0324', '2018-09-11', '0', '2018-09-11 12:42:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('75', '11', '1783', '2018-09-13', '0', '2018-09-13 14:46:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('76', '42', '0324', '2018-09-15', '0', '2018-09-15 15:25:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('77', '11', '0221', '2018-09-15', '0', '2018-09-15 15:39:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('78', '26', '2182', '2018-09-15', '0', '2018-09-15 15:42:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('79', '40', '0576', '2018-09-18', '0', '2018-09-18 10:38:32');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('80', '4', '1752', '2018-09-18', '0', '2018-09-18 11:11:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('81', '43', '2804', '2018-09-18', '0', '2018-09-18 14:47:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('82', '11', '0825', '2018-09-18', '0', '2018-09-18 14:54:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('83', '43', '4612', '2018-09-18', '0', '2018-09-18 15:02:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('84', '3', '0221', '2018-09-20', '0', '2018-09-20 13:44:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('85', '44', '6199', '2018-09-21', '0', '2018-09-21 09:38:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('86', '24', '0324', '2018-09-21', '0', '2018-09-21 16:19:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('87', '16', '6089', '2018-09-24', '0', '2018-09-24 15:36:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('88', '21', '0576', '2018-09-24', '0', '2018-09-24 15:43:18');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('89', '3', '6089', '2018-09-25', '0', '2018-09-25 15:05:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('90', '35', '0576', '2018-09-25', '0', '2018-09-25 15:13:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('91', '19', '6089', '2018-09-26', '0', '2018-09-26 14:46:22');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('92', '2', '7238', '2018-09-26', '0', '2018-09-26 14:58:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('93', '11', '7238', '2018-09-27', '0', '2018-09-27 15:50:24');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('94', '45', '2704', '2018-09-29', '0', '2018-09-29 15:53:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('95', '3', '7238', '2018-09-30', '0', '2018-09-30 15:42:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('96', '46', '3510', '2018-09-30', '0', '2018-09-30 15:47:24');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('97', '46', '0324', '2018-09-30', '0', '2018-09-30 15:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('98', '47', '0324', '2018-10-01', '0', '2018-10-01 15:30:29');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('99', '48', '3510', '2018-10-01', '0', '2018-10-01 15:44:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('100', '4', '0221', '2018-10-02', '0', '2018-10-02 15:25:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('101', '13', '3714', '2018-10-03', '0', '2018-10-03 15:05:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('102', '11', '3716', '2018-10-04', '0', '2018-10-04 15:48:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('103', '32', '8589', '2018-10-06', '0', '2018-10-06 15:08:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('104', '49', '0948', '2018-10-07', '0', '2018-10-07 15:14:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('105', '50', '2454', '2018-10-07', '0', '2018-10-07 15:41:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('106', '34', '0669', '2018-10-07', '0', '2018-10-07 15:51:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('107', '3', '1785', '2018-10-10', '0', '2018-10-10 16:06:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('108', '29', '0324', '2018-10-11', '0', '2018-10-11 16:21:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('109', '45', '3580', '2018-10-11', '0', '2018-10-11 16:32:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('110', '51', '2454', '2018-10-12', '0', '2018-10-12 09:49:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('111', '13', '0825', '2018-10-12', '0', '2018-10-12 17:04:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('112', '17', '3716', '2018-10-13', '0', '2018-10-13 15:31:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('113', '6', '7767', '2018-10-24', '0', '2018-10-24 13:03:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('114', '11', '7767', '2018-10-24', '0', '2018-10-24 14:07:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('115', '4', '7767', '2018-10-24', '0', '2018-10-24 16:29:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('116', '24', '6631', '2018-10-25', '0', '2018-10-25 11:32:59');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('117', '30', '0324', '2018-10-27', '0', '2018-10-27 10:18:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('118', '52', '0477', '2018-10-29', '0', '2018-10-29 12:17:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('119', '53', '0948', '2018-10-29', '0', '2018-10-29 12:29:22');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('120', '52', '0277', '2018-10-29', '0', '2018-10-29 12:38:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('121', '53', '2573', '2018-10-29', '0', '2018-10-29 17:04:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('122', '7', '4233', '2018-10-31', '0', '2018-10-31 11:13:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('123', '49', '2573', '2018-11-01', '0', '2018-11-01 11:34:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('124', '49', '8911', '2018-11-01', '0', '2018-11-01 11:39:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('125', '53', '8911', '2018-11-01', '0', '2018-11-01 15:40:11');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('126', '31', '0324', '2018-11-04', '0', '2018-11-04 16:58:32');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('127', '42', '0825', '2018-11-04', '0', '2018-11-04 17:00:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('128', '38', '0674', '2018-11-10', '0', '2018-11-10 15:12:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('129', '53', '0911', '2018-11-13', '0', '2018-11-13 15:23:43');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('130', '43', '5111', '2018-11-13', '0', '2018-11-13 15:40:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('131', '38', '0324', '2018-11-13', '0', '2018-11-13 15:43:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('132', '30', '8887', '2018-11-13', '0', '2018-11-13 15:45:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('133', '9', '3510', '2018-11-13', '0', '2018-11-13 15:50:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('134', '46', '0576', '2018-11-14', '0', '2018-11-14 15:48:18');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('135', '48', '0324', '2018-11-14', '0', '2018-11-14 16:02:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('136', '55', '0324', '2018-11-14', '0', '2018-11-14 16:14:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('137', '11', '8887', '2018-11-15', '0', '2018-11-15 15:14:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('138', '56', '3510', '2018-11-18', '0', '2018-11-18 15:49:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('139', '42', '7238', '2018-11-18', '0', '2018-11-18 16:08:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('140', '57', '9999', '2018-11-20', '0', '2018-11-20 14:53:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('141', '58', '8887', '2018-11-22', '0', '2018-11-22 16:34:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('142', '31', '3510', '2018-11-29', '0', '2018-11-29 14:52:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('143', '41', '4233', '2018-12-01', '0', '2018-12-01 09:53:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('144', '46', '4200', '2018-12-04', '0', '2018-12-04 13:58:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('145', '59', '0324', '2018-12-06', '0', '2018-12-06 12:21:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('146', '12', '4200', '2018-12-06', '0', '2018-12-06 15:52:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('147', '60', '0324', '2018-12-10', '0', '2018-12-10 15:43:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('148', '41', '4200', '2018-12-11', '0', '2018-12-11 12:47:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('149', '2', '4200', '2018-12-13', '0', '2018-12-13 15:22:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('150', '61', '0324', '2018-12-15', '0', '2018-12-15 14:55:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('151', '10', '4200', '2018-12-15', '0', '2018-12-15 15:09:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('152', '62', '0324', '2018-12-17', '0', '2018-12-17 16:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('153', '63', '0324', '2018-12-17', '0', '2018-12-17 16:52:11');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('154', '63', '4200', '2018-12-17', '0', '2018-12-17 16:52:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('155', '13', '4200', '2018-12-19', '0', '2018-12-19 13:36:54');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('156', '24', '3716', '2018-12-19', '0', '2018-12-19 17:05:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('157', '62', '4200', '2018-12-21', '0', '2018-12-21 09:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('158', '4', '4200', '2018-12-21', '0', '2018-12-21 15:16:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('159', '14', '4200', '2018-12-21', '0', '2018-12-21 17:26:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('160', '6', '4200', '2018-12-22', '0', '2018-12-22 16:15:43');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('161', '11', '4200', '2018-12-22', '0', '2018-12-22 16:18:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('162', '64', '4200', '2018-12-22', '0', '2018-12-22 16:34:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('163', '9', '4200', '2018-12-23', '0', '2018-12-23 12:09:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('164', '65', '4200', '2018-12-23', '0', '2018-12-23 15:01:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('165', '30', '4200', '2018-12-25', '0', '2018-12-25 17:59:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('166', '26', '4841', '2018-12-25', '0', '2018-12-25 18:08:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('167', '52', '0111', '2018-12-25', '0', '2018-12-25 18:17:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('168', '24', '1783', '2018-12-27', '0', '2018-12-27 11:42:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('169', '43', '4613', '2018-12-27', '0', '2018-12-27 11:49:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('170', '66', '4388', '2018-12-28', '0', '2018-12-28 13:30:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('171', '67', '0324', '2018-12-28', '0', '2018-12-28 16:55:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('172', '68', '4200', '2018-12-29', '0', '2018-12-29 15:23:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('173', '70', '0324', '2018-12-30', '0', '2018-12-30 16:40:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('174', '46', '7767', '2018-12-31', '0', '2018-12-31 15:59:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('175', '23', 'maijik', '2019-01-02', '0', '2019-01-02 11:17:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('176', '19', '4200', '2019-01-02', '0', '2019-01-02 11:20:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('177', '71', '0324', '2019-01-02', '0', '2019-01-02 15:34:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('178', '72', '4200', '2019-01-02', '0', '2019-01-02 15:41:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('179', '73', '0324', '2019-01-04', '0', '2019-01-04 10:10:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('180', '71', '4200', '2019-01-08', '0', '2019-01-08 14:59:43');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('181', '47', '7767', '2019-01-11', '0', '2019-01-11 14:28:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('182', '59', '7767', '2019-01-11', '0', '2019-01-11 16:28:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('183', '74', '0324', '2019-01-12', '0', '2019-01-12 17:02:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('184', '75', '0324', '2019-01-12', '0', '2019-01-12 17:10:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('185', '15', '4200', '2019-01-15', '0', '2019-01-15 11:17:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('186', '2', '6089', '2019-01-15', '0', '2019-01-15 11:23:54');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('187', '6', '8887', '2019-01-16', '0', '2019-01-16 16:30:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('188', '21', '4200', '2019-01-21', '0', '2019-01-21 12:22:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('189', '43', '2934', '2019-01-28', '0', '2019-01-28 11:46:29');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('190', '8', '4200', '2019-01-28', '0', '2019-01-28 16:56:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('191', '19', '8887', '2019-01-30', '0', '2019-01-30 11:43:19');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('192', '43', '2805', '2019-01-31', '0', '2019-01-31 15:22:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('193', '76', '0324', '2019-02-02', '0', '2019-02-02 16:11:59');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('194', '76', '4200', '2019-02-02', '0', '2019-02-02 16:12:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('195', '23', '0324', '2019-02-06', '0', '2019-02-06 11:55:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('196', '41', '0948', '2019-02-08', '0', '2019-02-08 10:14:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('197', '10', '0188', '2019-02-08', '0', '2019-02-08 10:18:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('198', '77', '0324', '2019-02-09', '0', '2019-02-09 16:19:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('199', '77', '6089', '2019-02-09', '0', '2019-02-09 16:20:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('200', '77', '0188', '2019-02-09', '0', '2019-02-09 16:21:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('201', '16', '4200', '2019-02-16', '0', '2019-02-16 12:36:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('202', '23', '3842', '2019-02-20', '0', '2019-02-20 13:01:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('203', '53', '2253', '2019-02-26', '0', '2019-02-26 12:53:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('204', '7', '8887', '2019-03-08', '0', '2019-03-08 10:12:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('205', '78', '0324', '2019-03-09', '0', '2019-03-09 17:32:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('206', '13', '6089', '2019-03-12', '0', '2019-03-12 17:02:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('207', '47', '4200', '2019-03-14', '0', '2019-03-14 11:21:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('208', '23', '7238', '2019-03-16', '0', '2019-03-16 15:50:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('209', '23', '1783', '2019-03-16', '0', '2019-03-16 15:51:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('210', '23', '4200', '2019-03-19', '0', '2019-03-19 12:32:51');


