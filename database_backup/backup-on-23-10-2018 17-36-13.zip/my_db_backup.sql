#
# TABLE STRUCTURE FOR: bills
#

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `bill_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `due` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `tax_amount` int(11) NOT NULL,
  `diposit_amount` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=latin1;

INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('1', '1', '0', '0', '0', '0', '0', '0', '0', '5', '0000-00-00', '0000-00-00', '2018-08-17', '2018-08-17 16:10:36');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('2', '2', '0', '0', '0', '0', '0', '0', '0', '3', '0000-00-00', '0000-00-00', '2018-08-17', '2018-08-17 16:12:53');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('3', '3', '0', '0', '0', '0', '0', '0', '0', '4', '0000-00-00', '0000-00-00', '2018-08-17', '2018-08-17 16:16:08');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('4', '4', '0', '0', '0', '0', '0', '0', '0', '2', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:06:34');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('5', '5', '0', '0', '0', '0', '0', '0', '0', '10', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:09:37');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('6', '6', '0', '0', '0', '0', '0', '0', '0', '7', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:12:13');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('7', '7', '0', '0', '0', '0', '0', '0', '0', '11', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:15:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('8', '8', '0', '0', '0', '0', '0', '0', '0', '9', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:20:30');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('9', '9', '0', '0', '0', '0', '0', '0', '0', '12', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:22:26');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('10', '10', '0', '0', '0', '0', '0', '0', '0', '15', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:24:59');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('11', '11', '0', '0', '0', '0', '0', '0', '0', '16', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:26:57');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('12', '12', '0', '0', '0', '0', '0', '0', '0', '17', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:28:51');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('13', '13', '0', '0', '0', '0', '0', '0', '0', '19', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:31:03');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('14', '14', '0', '0', '0', '0', '0', '0', '0', '21', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:38:56');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('15', '15', '0', '0', '0', '0', '0', '0', '0', '18', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:44:10');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('16', '16', '0', '0', '0', '0', '0', '0', '0', '13', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:57:26');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('17', '17', '0', '0', '0', '0', '0', '0', '0', '20', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 10:59:15');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('18', '18', '0', '0', '0', '0', '0', '0', '0', '6', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 11:10:10');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('19', '19', '0', '0', '0', '0', '0', '0', '0', '14', '2018-08-01', '2018-08-15', '2018-08-18', '2018-08-18 11:22:09');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('20', '20', '0', '0', '0', '0', '0', '0', '0', '9', '2018-08-16', '2018-08-31', '2018-08-31', '2018-08-31 14:35:22');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('21', '21', '0', '0', '0', '0', '0', '0', '0', '6', '2018-08-16', '2018-08-31', '2018-08-31', '2018-08-31 14:41:40');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('22', '22', '0', '0', '0', '0', '0', '0', '0', '5', '2018-08-16', '2018-08-31', '2018-08-31', '2018-08-31 14:46:49');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('23', '23', '0', '0', '0', '0', '0', '0', '0', '3', '2018-08-16', '2018-08-31', '2018-08-31', '2018-08-31 14:49:10');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('24', '24', '0', '0', '0', '0', '0', '0', '0', '4', '2018-08-16', '2018-08-31', '2018-08-31', '2018-08-31 14:51:52');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('25', '25', '0', '0', '0', '0', '0', '0', '0', '2', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 14:54:10');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('26', '26', '0', '0', '0', '0', '0', '0', '0', '20', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 14:55:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('27', '27', '0', '0', '0', '0', '0', '0', '0', '11', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 14:59:22');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('28', '28', '0', '0', '0', '0', '0', '0', '0', '13', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 15:02:39');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('29', '29', '0', '0', '0', '0', '0', '0', '0', '18', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 15:04:44');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('30', '30', '0', '0', '0', '0', '0', '0', '0', '21', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 15:08:26');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('31', '31', '0', '0', '0', '0', '0', '0', '0', '19', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 15:10:52');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('32', '32', '0', '0', '0', '0', '0', '0', '0', '16', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 15:12:53');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('33', '33', '0', '0', '0', '0', '0', '0', '0', '12', '0000-00-00', '0000-00-00', '2018-08-31', '2018-08-31 15:15:13');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('34', '34', '0', '0', '0', '0', '0', '0', '0', '23', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 10:25:11');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('35', '35', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-01', '2018-09-06', '2018-09-07', '2018-09-07 10:31:17');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('36', '36', '0', '0', '0', '0', '0', '0', '0', '27', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 10:34:42');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('37', '37', '0', '0', '0', '0', '0', '0', '0', '26', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 10:39:43');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('38', '38', '0', '0', '0', '0', '0', '0', '0', '29', '0000-00-00', '0000-00-00', '2018-09-07', '2018-09-07 10:41:59');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('39', '39', '0', '0', '0', '0', '0', '0', '0', '37', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 10:44:15');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('40', '40', '0', '0', '0', '0', '0', '0', '0', '24', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 10:49:56');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('41', '41', '0', '0', '0', '0', '0', '0', '0', '32', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 10:59:45');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('42', '42', '0', '0', '0', '0', '0', '0', '0', '33', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 11:02:41');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('43', '43', '0', '0', '0', '0', '0', '0', '0', '25', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 11:06:57');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('44', '44', '0', '0', '0', '0', '0', '0', '0', '35', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 11:11:31');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('45', '45', '0', '0', '0', '0', '0', '0', '0', '36', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 12:19:08');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('46', '46', '0', '0', '0', '0', '0', '0', '0', '38', '0000-00-00', '0000-00-00', '2018-09-07', '2018-09-07 12:21:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('47', '47', '0', '0', '0', '0', '0', '0', '0', '31', '2018-08-31', '2018-09-06', '2018-09-07', '2018-09-07 13:51:22');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('48', '48', '0', '0', '0', '0', '0', '0', '0', '32', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 10:06:53');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('49', '49', '0', '0', '0', '0', '0', '0', '0', '24', '2018-09-06', '2018-09-13', '2018-09-14', '2018-09-14 10:12:00');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('50', '50', '0', '0', '0', '0', '0', '0', '0', '37', '2018-09-06', '2018-09-13', '2018-09-14', '2018-09-14 10:14:04');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('51', '51', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-06', '2018-09-13', '2018-09-14', '2018-09-14 10:16:49');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('52', '52', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-12', '2018-09-13', '2018-09-14', '2018-09-14 10:26:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('53', '53', '0', '0', '0', '0', '0', '0', '0', '29', '2018-09-06', '2018-09-13', '2018-09-14', '2018-09-14 10:31:04');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('54', '54', '0', '0', '0', '0', '0', '0', '0', '27', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 10:33:34');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('55', '55', '0', '0', '0', '0', '0', '0', '0', '20', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 10:36:18');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('56', '56', '0', '0', '0', '0', '0', '0', '0', '25', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 10:39:09');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('57', '57', '0', '0', '0', '0', '0', '0', '0', '36', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 11:29:19');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('58', '58', '0', '0', '0', '0', '0', '0', '0', '31', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 11:33:15');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('59', '59', '0', '0', '0', '0', '0', '0', '0', '26', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 11:41:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('60', '60', '0', '0', '0', '0', '0', '0', '0', '34', '2018-09-06', '2018-09-13', '2018-09-14', '2018-09-14 11:45:05');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('61', '61', '0', '0', '0', '0', '0', '0', '0', '35', '2018-09-07', '2018-09-13', '2018-09-14', '2018-09-14 12:13:22');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('62', '62', '0', '0', '0', '0', '0', '0', '0', '27', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 09:52:04');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('63', '63', '0', '0', '0', '0', '0', '0', '0', '24', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 09:58:07');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('64', '64', '0', '0', '0', '0', '0', '0', '0', '29', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:02:51');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('65', '65', '0', '0', '0', '0', '0', '0', '0', '37', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:06:51');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('66', '66', '0', '0', '0', '0', '0', '0', '0', '32', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:12:12');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('67', '67', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:17:36');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('68', '68', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-18', '2018-09-20', '2018-09-21', '2018-09-21 10:24:18');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('69', '69', '0', '0', '0', '0', '0', '0', '0', '20', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:26:51');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('70', '70', '0', '0', '0', '0', '0', '0', '0', '31', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:29:21');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('71', '71', '0', '0', '0', '0', '0', '0', '0', '25', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:32:02');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('72', '72', '0', '0', '0', '0', '0', '0', '0', '36', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:34:17');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('73', '73', '0', '0', '0', '0', '0', '0', '0', '26', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 10:36:39');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('74', '74', '0', '0', '0', '0', '0', '0', '0', '32', '2018-09-19', '2018-09-20', '2018-09-21', '2018-09-21 11:40:23');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('75', '75', '0', '0', '0', '0', '0', '0', '0', '38', '2018-09-14', '2018-09-20', '2018-09-21', '2018-09-21 16:12:20');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('76', '76', '0', '0', '0', '0', '0', '0', '0', '34', '0000-00-00', '0000-00-00', '2018-09-21', '2018-09-21 16:15:20');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('77', '77', '0', '0', '0', '0', '0', '0', '0', '43', '0000-00-00', '0000-00-00', '2018-09-21', '2018-09-21 16:26:36');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('78', '78', '0', '0', '0', '0', '0', '0', '0', '27', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 09:59:42');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('79', '79', '0', '0', '0', '0', '0', '0', '0', '29', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:03:51');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('80', '80', '0', '0', '0', '0', '0', '0', '0', '20', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:05:39');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('81', '81', '0', '0', '0', '0', '0', '0', '0', '24', '2018-09-21', '2018-09-23', '2018-09-28', '2018-09-28 10:08:44');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('82', '82', '0', '0', '0', '0', '0', '0', '0', '24', '2018-09-24', '2018-09-27', '2018-09-28', '2018-09-28 10:11:18');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('83', '83', '0', '0', '0', '0', '0', '0', '0', '32', '0000-00-00', '0000-00-00', '2018-09-28', '2018-09-28 10:15:05');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('84', '84', '0', '0', '0', '0', '0', '0', '0', '32', '2018-09-26', '2018-09-27', '2018-09-28', '2018-09-28 10:17:24');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('85', '85', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:20:18');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('86', '86', '0', '0', '0', '0', '0', '0', '0', '36', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:24:08');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('87', '87', '0', '0', '0', '0', '0', '0', '0', '26', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:25:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('88', '88', '0', '0', '0', '0', '0', '0', '0', '25', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:28:34');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('89', '89', '0', '0', '0', '0', '0', '0', '0', '31', '2018-09-21', '2018-09-27', '2018-09-28', '2018-09-28 10:58:38');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('90', '90', '0', '0', '0', '0', '0', '0', '0', '38', '0000-00-00', '0000-00-00', '2018-09-28', '2018-09-28 11:03:40');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('91', '91', '0', '0', '0', '0', '0', '0', '0', '1', '0000-00-00', '0000-00-00', '2018-09-29', '2018-09-29 19:12:03');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('92', '92', '0', '0', '0', '0', '0', '0', '0', '36', '2018-09-27', '2018-10-03', '2018-10-05', '2018-10-05 09:50:20');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('93', '93', '0', '0', '0', '0', '0', '0', '0', '23', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 09:55:52');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('94', '94', '0', '0', '0', '0', '0', '0', '0', '24', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:01:03');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('95', '95', '0', '0', '0', '0', '0', '0', '0', '32', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:05:29');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('96', '96', '0', '0', '0', '0', '0', '0', '0', '27', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:10:07');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('97', '97', '0', '0', '0', '0', '0', '0', '0', '29', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:12:27');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('98', '98', '0', '0', '0', '0', '0', '0', '0', '25', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:15:35');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('99', '99', '0', '0', '0', '0', '0', '0', '0', '26', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:19:07');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('100', '100', '0', '0', '0', '0', '0', '0', '0', '31', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 10:22:05');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('101', '101', '0', '0', '0', '0', '0', '0', '0', '38', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 11:16:15');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('102', '102', '0', '0', '0', '0', '0', '0', '0', '46', '2018-09-28', '2018-10-04', '2018-10-05', '2018-10-05 17:34:12');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('103', '103', '0', '0', '0', '0', '0', '0', '0', '36', '2018-10-04', '2018-10-10', '2018-10-11', '2018-10-11 16:41:39');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('104', '104', '0', '0', '0', '0', '0', '0', '0', '27', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 09:57:11');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('105', '105', '0', '0', '0', '0', '0', '0', '0', '23', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:03:35');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('106', '106', '0', '0', '0', '0', '0', '0', '0', '24', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:07:34');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('107', '107', '0', '0', '0', '0', '0', '0', '0', '32', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:13:00');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('108', '108', '0', '0', '0', '0', '0', '0', '0', '20', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:18:11');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('109', '109', '0', '0', '0', '0', '0', '0', '0', '31', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:28:40');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('110', '110', '0', '0', '0', '0', '0', '0', '0', '29', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:30:26');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('111', '111', '0', '0', '0', '0', '0', '0', '0', '25', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:32:26');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('112', '112', '0', '0', '0', '0', '0', '0', '0', '26', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:33:49');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('113', '113', '0', '0', '0', '0', '0', '0', '0', '38', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 10:37:09');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('114', '114', '0', '0', '0', '0', '0', '0', '0', '34', '0000-00-00', '0000-00-00', '2018-10-12', '2018-10-12 12:51:42');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('115', '115', '0', '0', '0', '0', '0', '0', '0', '45', '0000-00-00', '0000-00-00', '2018-10-12', '2018-10-12 12:53:56');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('116', '116', '0', '0', '0', '0', '0', '0', '0', '51', '2018-10-05', '2018-10-11', '2018-10-12', '2018-10-12 13:25:42');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('117', '117', '0', '0', '0', '0', '0', '0', '0', '36', '2018-10-11', '2018-10-17', '2018-10-18', '2018-10-18 11:34:57');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('118', '118', '0', '0', '0', '0', '0', '0', '0', '27', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 09:51:42');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('119', '119', '0', '0', '0', '0', '0', '0', '0', '29', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 09:53:45');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('120', '120', '0', '0', '0', '0', '0', '0', '0', '23', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 09:57:30');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('121', '121', '0', '0', '0', '0', '0', '0', '0', '24', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:02:19');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('122', '122', '0', '0', '0', '0', '0', '0', '0', '32', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:05:09');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('123', '123', '0', '0', '0', '0', '0', '0', '0', '37', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:08:20');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('124', '124', '0', '0', '0', '0', '0', '0', '0', '31', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:11:22');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('125', '125', '0', '0', '0', '0', '0', '0', '0', '25', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:13:30');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('126', '126', '0', '0', '0', '0', '0', '0', '0', '26', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:15:43');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('127', '127', '0', '0', '0', '0', '0', '0', '0', '38', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:17:24');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('128', '128', '0', '0', '0', '0', '0', '0', '0', '34', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 10:19:59');
INSERT INTO `bills` (`bill_id`, `invoice_no`, `bill_amount`, `due_amount`, `total_amount`, `due`, `tax`, `tax_amount`, `diposit_amount`, `client_id`, `from_date`, `to_date`, `entry_date`, `created_date`) VALUES ('129', '129', '0', '0', '0', '0', '0', '0', '0', '24', '2018-10-12', '2018-10-18', '2018-10-20', '2018-10-20 11:29:40');


#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('1', 'sampat', '8602442648', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:09:12');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('2', 'maze buildcon', '1111111111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:26:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('3', 'sayta', '1011111111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:28:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('4', 'sardar ji', '1234567011', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:30:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('5', 'gangotri ', '1200311111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:31:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('6', 'gaurav jain', '2222000002', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:32:21');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('7', 'desai ji', '3333333333', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:33:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('8', 'hebal som', '3333333331', 'khndwa road indore m.p', '2018-08-03', '0', '2018-08-03 10:41:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('9', 'singhl sahb', '1110000007', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:42:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('10', 'mukesh prajapat', '9827250327', 'indore m.p', '2018-08-03', '0', '2018-08-03 11:10:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('11', 'makhija ji', '5555555555', 'indore m.p', '2018-08-03', '0', '2018-08-03 11:15:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('12', 'natraj tiles', '6666666666', 'indore m.p', '2018-08-03', '0', '2018-08-03 14:26:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('13', 'badwani ji', '1000001112', 'khndwa road indore', '2018-08-07', '0', '2018-08-07 18:10:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('14', 'ultra tech', '4444440909', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:15:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('15', 'kukreja ji', '7070708888', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:19:17');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('16', 'jk buildcon', '1010101010', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:37:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('17', 'parsawnath ji', '8989898980', 'indore m.p', '2018-08-08', '0', '2018-08-08 10:33:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('18', 'jai baba', '7030500005', 'indore m.p', '2018-08-08', '0', '2018-08-08 10:39:53');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('19', 'ML AGARWAL SCHOOL', '6565656565', 'INDORE MP', '2018-08-08', '0', '2018-08-08 16:06:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('20', 'kapil pariya', '5050505060', 'indore mp', '2018-08-08', '0', '2018-08-08 16:09:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('21', 'capital', '7676767687', 'brg indore', '2018-08-13', '0', '2018-08-13 11:50:57');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('22', 'umriya bricks factory', '5454545454', 'indore umriya', '2018-08-18', '0', '2018-08-18 11:32:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('23', 'D S', '1010203030', 'INDORE M.P', '2018-09-01', '0', '2018-09-01 11:36:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('24', 'RM', '9999999998', 'INDORE', '2018-09-01', '0', '2018-09-01 11:44:47');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('25', 'ARJUN JAT', '2222111134', 'INDORE', '2018-09-01', '0', '2018-09-01 11:46:57');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('26', 'PANKAJ MAKHIJA', '9898765432', 'INDORE', '2018-09-01', '0', '2018-09-01 11:49:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('27', 'SHER SINGH', '1212121234', 'INDORE', '2018-09-01', '0', '2018-09-01 11:51:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('28', '892', '8787690901', 'INDORE', '2018-09-01', '0', '2018-09-01 11:55:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('29', 'BANTY RAWLIYA', '3456783490', 'INDORE', '2018-09-01', '0', '2018-09-01 11:56:35');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('30', 'CASH', '0909090909', 'INDORE', '2018-09-01', '0', '2018-09-01 12:07:33');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('31', 'PL', '1212347890', 'INDORE', '2018-09-01', '0', '2018-09-01 12:20:37');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('32', 'ms', '4563217890', 'indore', '2018-09-01', '0', '2018-09-01 16:38:45');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('33', 'CHNDU', '9898765431', 'INDORE', '2018-09-01', '0', '2018-09-01 16:57:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('34', 'narendra khndwal', '6767890564', 'indore', '2018-09-02', '0', '2018-09-02 11:45:55');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('35', 'KAPIL PARIYA 8 MIL', '2323456781', 'INDORE', '2018-09-02', '0', '2018-09-02 12:16:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('36', 'sanny jat', '8787906547', 'indore', '2018-09-03', '0', '2018-09-03 12:11:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('37', 'RAHUL', '9807654321', 'INDORE', '2018-09-03', '0', '2018-09-03 12:28:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('38', 'SEWAK RAM', '8888899999', 'INDORE', '2018-09-03', '0', '2018-09-03 12:32:24');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('39', 'lakhn jat', '0909090901', 'indore', '2018-09-06', '0', '2018-09-06 14:55:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('40', 'sunil sheth', '4545678632', 'indore', '2018-09-06', '0', '2018-09-06 15:06:22');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('41', 'MAHESH PATIDAR', '8976543214', 'INDORE', '2018-09-11', '0', '2018-09-11 12:42:00');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('42', 'goyal sahab', '5678432103', 'indore mp', '2018-09-15', '0', '2018-09-15 15:24:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('43', 'mangesh yadav', '9080706054', 'indore mp', '2018-09-18', '0', '2018-09-18 14:46:58');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('44', 'shiv ram', '6070805432', 'indore mp', '2018-09-21', '0', '2018-09-21 09:38:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('45', 'sanjay khndewal', '9712309875', 'indore', '2018-09-29', '0', '2018-09-29 15:52:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('46', 'pahuja ji 8 mil', '9087654321', 'INDORE', '2018-09-30', '0', '2018-10-01 15:14:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('47', 'Lokesh ji ', '1029304059', 'indore mp', '2018-10-01', '0', '2018-10-01 15:30:10');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('48', 'Trilok poltri farm', '3040501065', 'indore mp', '2018-10-01', '0', '2018-10-01 15:44:03');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('49', 'DARWAR', '8123123456', 'INDORE', '2018-10-07', '0', '2018-10-07 15:14:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('50', 'MONU ARORA', '2134333333', 'INDORE', '2018-10-07', '0', '2018-10-07 15:40:45');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('51', 'manu arora', '9870984563', 'indore', '2018-10-12', '0', '2018-10-12 09:48:42');


#
# TABLE STRUCTURE FOR: dues
#

DROP TABLE IF EXISTS `dues`;

CREATE TABLE `dues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('1', '5', '0', '2018-08-17 16:10:36');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('2', '3', '0', '2018-08-17 16:12:53');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('3', '4', '0', '2018-08-17 16:16:08');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('4', '2', '0', '2018-08-18 10:06:34');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('5', '10', '0', '2018-08-18 10:09:37');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('6', '7', '0', '2018-08-18 10:12:13');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('7', '11', '0', '2018-08-18 10:15:38');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('8', '9', '0', '2018-08-18 10:20:30');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('9', '12', '0', '2018-08-18 10:22:26');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('10', '15', '0', '2018-08-18 10:24:59');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('11', '16', '0', '2018-08-18 10:26:57');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('12', '17', '0', '2018-08-18 10:28:51');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('13', '19', '0', '2018-08-18 10:31:03');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('14', '21', '0', '2018-08-18 10:38:56');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('15', '18', '0', '2018-08-18 10:44:10');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('16', '13', '0', '2018-08-18 10:57:26');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('17', '20', '0', '2018-08-18 10:59:15');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('18', '6', '0', '2018-08-18 11:10:10');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('19', '14', '0', '2018-08-18 11:22:09');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('20', '23', '0', '2018-09-07 10:25:11');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('21', '27', '0', '2018-09-07 10:34:42');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('22', '26', '0', '2018-09-07 10:39:43');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('23', '29', '0', '2018-09-07 10:41:59');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('24', '37', '0', '2018-09-07 10:44:15');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('25', '24', '0', '2018-09-07 10:49:56');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('26', '32', '0', '2018-09-07 10:59:45');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('27', '33', '0', '2018-09-07 11:02:41');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('28', '25', '0', '2018-09-07 11:06:57');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('29', '35', '0', '2018-09-07 11:11:31');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('30', '36', '0', '2018-09-07 12:19:08');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('31', '38', '0', '2018-09-07 12:21:38');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('32', '31', '0', '2018-09-07 13:51:22');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('33', '34', '0', '2018-09-14 11:45:05');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('34', '43', '0', '2018-09-21 16:26:35');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('35', '1', '0', '2018-09-29 19:12:03');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('36', '46', '0', '2018-10-05 17:34:12');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('37', '45', '0', '2018-10-12 12:53:56');
INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('38', '51', '0', '2018-10-12 13:25:42');


#
# TABLE STRUCTURE FOR: gate_pass
#

DROP TABLE IF EXISTS `gate_pass`;

CREATE TABLE `gate_pass` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `serial_no` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `in_time` varchar(200) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `client_id` varchar(250) NOT NULL,
  `vehicle_id` varchar(250) NOT NULL,
  `material_id` varchar(250) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `bill_id` varchar(250) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `entry_date` varchar(250) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=latin1;

INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('4', '316', '2018-10-19', '00:00 AM', '00:00 AM', '33', '47', '1', '9', '', '', '2018-10-21', '2018-10-21 14:38:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('5', '317', '2018-10-19', '00:00 AM', '00:00 AM', '33', '47', '1', '9', '', '', '2018-10-21', '2018-10-21 14:40:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('6', '318', '2018-10-20', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-21', '2018-10-21 14:41:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('7', '319', '2018-10-20', '00:00 AM', '00:00 AM', '25', '46', '1', '9', '', '', '2018-10-21', '2018-10-21 14:41:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('8', '320', '2018-10-20', '00:00 AM', '00:00 AM', '4', '4', '3', '10', '', '', '2018-10-21', '2018-10-21 14:42:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('9', '321', '2018-10-20', '00:00 AM', '00:00 AM', '25', '46', '1', '9', '', '', '2018-10-21', '2018-10-21 14:43:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('10', '322', '2018-10-20', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-21', '2018-10-21 14:47:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('11', '323', '2018-10-20', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-21', '2018-10-21 14:48:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('12', '324', '2018-10-20', '00:00 AM', '00:00 AM', '25', '46', '1', '9', '', '', '2018-10-21', '2018-10-21 14:49:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('13', '325', '2018-10-20', '00:00 AM', '00:00 AM', '23', '33', '3', '4', '', '', '2018-10-21', '2018-10-21 14:51:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('14', '326', '2018-10-20', '00:00 AM', '00:00 AM', '23', '33', '1', '4', '', '', '2018-10-21', '2018-10-21 14:51:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('15', '327', '2018-10-21', '00:00 AM', '00:00 AM', '23', '41', '1', '9', '', '', '2018-10-21', '2018-10-21 14:52:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('16', '328', '2018-10-21', '00:00 AM', '00:00 AM', '46', '97', '1', '22', '', '', '2018-10-21', '2018-10-21 14:53:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('17', '329', '2018-10-21', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '', '', '2018-10-21', '2018-10-21 14:54:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('18', '330', '2018-10-21', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '', '', '2018-10-21', '2018-10-21 14:54:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('19', '331', '2018-10-21', '00:00 AM', '00:00 AM', '36', '55', '1', '9', '', '', '2018-10-21', '2018-10-21 14:55:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('20', '332', '2018-10-21', '00:00 AM', '00:00 AM', '32', '44', '2', '10', '', '', '2018-10-21', '2018-10-21 14:56:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('21', '333', '2018-10-21', '00:00 AM', '00:00 AM', '46', '97', '1', '22', '', '', '2018-10-21', '2018-10-21 14:57:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('22', '334', '2018-10-21', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '', '', '2018-10-21', '2018-10-21 14:58:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('23', '335', '2018-10-21', '00:00 AM', '00:00 AM', '46', '97', '1', '22', '', '', '2018-10-21', '2018-10-21 14:59:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('24', '336', '2018-10-21', '00:00 AM', '00:00 AM', '27', '37', '5', '4', '', '', '2018-10-21', '2018-10-21 14:59:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('25', '337', '2018-10-21', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '', '', '2018-10-21', '2018-10-21 15:00:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('26', '338', '2018-10-21', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '', '', '2018-10-21', '2018-10-21 15:00:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('27', '339', '2018-10-21', '00:00 AM', '00:00 AM', '46', '97', '1', '22', '', '', '2018-10-21', '2018-10-21 15:01:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('28', '340', '2018-10-21', '00:00 AM', '00:00 AM', '32', '44', '3', '10', '', '', '2018-10-21', '2018-10-21 15:02:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('29', '341', '2018-10-21', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-21', '2018-10-21 15:02:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('30', '342', '2018-10-21', '00:00 AM', '00:00 AM', '46', '97', '1', '22', '', '', '2018-10-21', '2018-10-21 15:03:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('31', '343', '2018-10-21', '00:00 AM', '00:00 AM', '25', '46', '3', '9', '', '', '2018-10-21', '2018-10-21 15:04:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('32', '344', '2018-10-21', '00:00 AM', '00:00 AM', '34', '48', '1', '10', '', '', '2018-10-21', '2018-10-21 15:05:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('33', '345', '2018-10-21', '00:00 AM', '00:00 AM', '11', '11', '7', '22', '', '', '2018-10-21', '2018-10-21 15:06:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('34', '346', '2018-10-21', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '', '', '2018-10-21', '2018-10-21 15:06:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('35', '347', '2018-10-21', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '', '', '2018-10-21', '2018-10-21 15:07:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('36', '348', '2018-10-21', '00:00 AM', '00:00 AM', '26', '51', '1', '10', '', '', '2018-10-21', '2018-10-21 15:08:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('37', '349', '2018-10-21', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '', '', '2018-10-21', '2018-10-21 15:09:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('38', '350', '2018-10-21', '00:00 AM', '00:00 AM', '36', '55', '3', '9', '', '', '2018-10-21', '2018-10-21 15:09:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('39', '351', '2018-10-21', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '', '', '2018-10-21', '2018-10-21 15:58:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('40', '352', '2018-10-21', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '', '', '2018-10-22', '2018-10-22 15:31:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('41', '353', '2018-10-21', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '', '', '2018-10-22', '2018-10-22 15:32:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('42', '354', '2018-10-21', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-22', '2018-10-22 15:32:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('43', '355', '2018-10-21', '00:00 AM', '00:00 AM', '26', '51', '7', '10', '', '', '2018-10-22', '2018-10-22 15:33:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('44', '356', '2018-10-21', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '', '', '2018-10-22', '2018-10-22 15:34:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('45', '357', '2018-10-21', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-22', '2018-10-22 15:34:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('46', '358', '2018-10-21', '00:00 AM', '00:00 AM', '31', '42', '2', '9', '', '', '2018-10-22', '2018-10-22 15:35:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('47', '359', '2018-10-21', '00:00 AM', '00:00 AM', '18', '18', '5', '22', '', '', '2018-10-22', '2018-10-22 15:36:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('48', '360', '2018-10-21', '00:00 AM', '00:00 AM', '31', '42', '2', '9', '', '', '2018-10-22', '2018-10-22 15:36:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('49', '361', '2018-10-21', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '', '', '2018-10-22', '2018-10-22 15:37:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('50', '362', '2018-10-21', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '', '', '2018-10-22', '2018-10-22 15:38:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('51', '363', '2018-10-21', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '', '', '2018-10-22', '2018-10-22 15:39:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('52', '364', '2018-10-21', '00:00 AM', '00:00 AM', '19', '91', '7', '9', '', '', '2018-10-22', '2018-10-22 15:39:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('53', '365', '2018-10-21', '00:00 AM', '00:00 AM', '19', '91', '7', '9', '', '', '2018-10-22', '2018-10-22 15:40:31');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('54', '366', '2018-10-22', '00:00 AM', '00:00 AM', '38', '57', '1', '9', '', '', '2018-10-22', '2018-10-22 15:41:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('55', '367', '2018-10-22', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '', '', '2018-10-22', '2018-10-22 15:42:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('56', '368', '2018-10-22', '00:00 AM', '00:00 AM', '37', '56', '1', '9', '', '', '2018-10-22', '2018-10-22 15:44:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('57', '369', '2018-10-22', '00:00 AM', '00:00 AM', '32', '43', '1', '9', '', '', '2018-10-22', '2018-10-22 15:44:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('58', '370', '2018-10-22', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '', '', '2018-10-22', '2018-10-22 15:45:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('59', '371', '2018-10-22', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '', '', '2018-10-22', '2018-10-22 15:45:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('60', '372', '2018-10-22', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '', '', '2018-10-22', '2018-10-22 15:46:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('61', '373', '2018-10-22', '00:00 AM', '00:00 AM', '24', '45', '3', '9', '', '', '2018-10-22', '2018-10-22 15:47:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('62', '374', '2018-10-22', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '', '', '2018-10-22', '2018-10-22 15:47:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('63', '375', '2018-10-22', '00:00 AM', '00:00 AM', '29', '38', '5', '4', '', '', '2018-10-22', '2018-10-22 15:48:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('64', '376', '2018-10-22', '00:00 AM', '00:00 AM', '4', '4', '5', '22', '', '', '2018-10-22', '2018-10-22 15:48:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('65', '377', '2018-10-22', '00:00 AM', '00:00 AM', '25', '46', '1', '8', '', '', '2018-10-22', '2018-10-22 15:49:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('66', '378', '2018-10-22', '00:00 AM', '00:00 AM', '32', '44', '1', '10', '', '', '2018-10-22', '2018-10-22 15:50:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('67', '379', '2018-10-22', '00:00 AM', '00:00 AM', '30', '40', '1', '10', '', '', '2018-10-22', '2018-10-22 15:51:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('68', '380', '2018-10-22', '00:00 AM', '00:00 AM', '25', '35', '5', '9', '', '', '2018-10-22', '2018-10-22 15:52:05');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('69', '381', '2018-10-22', '00:00 AM', '00:00 AM', '36', '55', '7', '9', '', '', '2018-10-22', '2018-10-22 15:52:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('70', '382', '2018-10-22', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '', '', '2018-10-22', '2018-10-22 15:53:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('71', '383', '2018-10-22', '00:00 AM', '00:00 AM', '24', '34', '7', '9', '', '', '2018-10-22', '2018-10-22 15:54:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('72', '384', '2018-10-22', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '', '', '2018-10-22', '2018-10-22 15:55:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('73', '385', '2018-10-22', '00:00 AM', '00:00 AM', '12', '12', '3', '22', '', '', '2018-10-22', '2018-10-22 15:55:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('74', '386', '2018-10-22', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '', '', '2018-10-22', '2018-10-22 15:56:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('75', '387', '2018-10-22', '00:00 AM', '00:00 AM', '37', '56', '1', '9', '', '', '2018-10-22', '2018-10-22 15:57:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('76', '388', '2018-10-22', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '', '', '2018-10-22', '2018-10-22 15:58:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('77', '389', '2018-10-22', '00:00 AM', '00:00 AM', '34', '48', '1', '10', '', '', '2018-10-22', '2018-10-22 15:59:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('78', '390', '2018-10-22', '00:00 AM', '00:00 AM', '25', '46', '1', '9', '', '', '2018-10-22', '2018-10-22 15:59:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('79', '391', '2018-10-22', '00:00 AM', '00:00 AM', '24', '45', '2', '9', '', '', '2018-10-22', '2018-10-22 16:00:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('80', '392', '2018-10-22', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '', '', '2018-10-22', '2018-10-22 16:00:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('81', '393', '2018-10-22', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '', '', '2018-10-23', '2018-10-23 17:01:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('82', '394', '2018-10-22', '00:00 AM', '00:00 AM', '14', '14', '7', '20', '', '', '2018-10-23', '2018-10-23 17:02:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('83', '395', '2018-10-22', '00:00 AM', '00:00 AM', '30', '40', '7', '10', '', '', '2018-10-23', '2018-10-23 17:02:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('84', '396', '2018-10-22', '00:00 AM', '00:00 AM', '23', '33', '1', '4', '', '', '2018-10-23', '2018-10-23 17:04:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('85', '398', '2018-10-22', '00:00 AM', '00:00 AM', '41', '74', '1', '22', '', '', '2018-10-23', '2018-10-23 17:06:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('86', '399', '2018-10-22', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '', '', '2018-10-23', '2018-10-23 17:06:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('87', '400', '2018-10-22', '00:00 AM', '00:00 AM', '18', '18', '3', '22', '', '', '2018-10-23', '2018-10-23 17:07:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('88', '401', '2018-10-22', '00:00 AM', '00:00 AM', '19', '19', '1', '22', '', '', '2018-10-23', '2018-10-23 17:07:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('89', '402', '2018-10-23', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '', '', '2018-10-23', '2018-10-23 17:08:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('90', '403', '2018-10-23', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '', '', '2018-10-23', '2018-10-23 17:09:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('91', '404', '2018-10-23', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '', '', '2018-10-23', '2018-10-23 17:09:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('92', '405', '2018-10-23', '00:00 AM', '00:00 AM', '32', '44', '3', '10', '', '', '2018-10-23', '2018-10-23 17:10:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('93', '406', '2018-10-23', '00:00 AM', '00:00 AM', '36', '55', '1', '9', '', '', '2018-10-23', '2018-10-23 17:10:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('94', '407', '2018-10-23', '00:00 AM', '00:00 AM', '6', '6', '5', '20', '', '', '2018-10-23', '2018-10-23 17:11:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('95', '408', '2018-10-23', '00:00 AM', '00:00 AM', '20', '60', '3', '9', '', '', '2018-10-23', '2018-10-23 17:14:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('96', '409', '2018-10-23', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '', '', '2018-10-23', '2018-10-23 17:15:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('97', '410', '2018-10-23', '00:00 AM', '00:00 AM', '32', '43', '7', '9', '', '', '2018-10-23', '2018-10-23 17:16:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('98', '411', '2018-10-23', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '', '', '2018-10-23', '2018-10-23 17:16:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('99', '412', '2018-10-23', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '', '', '2018-10-23', '2018-10-23 17:17:10');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('100', '413', '2018-10-23', '00:00 AM', '00:00 AM', '13', '111', '1', '10', '', '', '2018-10-23', '2018-10-23 17:17:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('101', '414', '2018-10-23', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '', '', '2018-10-23', '2018-10-23 17:18:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('102', '415', '2018-10-23', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '', '', '2018-10-23', '2018-10-23 17:19:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('103', '416', '2018-10-23', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '', '', '2018-10-23', '2018-10-23 17:19:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('104', '417', '2018-10-23', '00:00 AM', '00:00 AM', '36', '55', '3', '9', '', '', '2018-10-23', '2018-10-23 17:20:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('105', '418', '2018-10-23', '00:00 AM', '00:00 AM', '48', '99', '1', '10', '', '', '2018-10-23', '2018-10-23 17:20:51');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('106', '419', '2018-10-23', '00:00 AM', '00:00 AM', '23', '41', '1', '9', '', '', '2018-10-23', '2018-10-23 17:21:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('107', '420', '2018-10-23', '00:00 AM', '00:00 AM', '13', '111', '1', '10', '', '', '2018-10-23', '2018-10-23 17:21:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('108', '421', '2018-10-23', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '', '', '2018-10-23', '2018-10-23 17:23:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('109', '422', '2018-10-23', '00:00 AM', '00:00 AM', '24', '45', '7', '9', '', '', '2018-10-23', '2018-10-23 17:24:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('110', '424', '2018-10-23', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '', '', '2018-10-23', '2018-10-23 17:24:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('111', '425', '2018-10-23', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '', '', '2018-10-23', '2018-10-23 17:25:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('112', '426', '2018-10-23', '00:00 AM', '00:00 AM', '23', '49', '1', '10', '', '', '2018-10-23', '2018-10-23 17:25:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('113', '427', '2018-10-23', '00:00 AM', '00:00 AM', '38', '62', '1', '9', '', '', '2018-10-23', '2018-10-23 17:26:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('114', '428', '2018-10-23', '00:00 AM', '00:00 AM', '23', '32', '1', '5', '', '', '2018-10-23', '2018-10-23 17:27:05');


#
# TABLE STRUCTURE FOR: materials
#

DROP TABLE IF EXISTS `materials`;

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('1', '20 MM', '2018-07-24', '0', '2018-07-31 22:55:28');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('2', '10 MM', '2018-07-24', '0', '2018-07-31 22:55:19');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('3', '6 MM', '2018-07-24', '0', '2018-07-31 22:55:10');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('4', '3 shoot', '2018-07-24', '0', '2018-07-31 22:55:43');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('5', 'Dhoola', '2018-07-24', '0', '2018-07-31 22:56:47');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('6', 'M Send', '2018-07-28', '0', '2018-07-31 22:57:00');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('7', 'Reti', '2018-07-28', '0', '2018-07-31 22:57:11');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('8', '40 mm', '2018-09-18', '0', '2018-09-18 14:51:35');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('9', 'GSB', '2018-10-12', '0', '2018-10-12 17:07:39');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('10', 'moram', '2018-10-16', '0', '2018-10-16 16:42:00');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `email`, `password`, `role`, `created_date`, `name`, `mobile_no`, `description`, `entry_date`) VALUES ('1', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2018-07-22 14:41:58', 'Admin', '9098343935', '', '2018-07-20');


#
# TABLE STRUCTURE FOR: vehicles
#

DROP TABLE IF EXISTS `vehicles`;

CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vehicle_no` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('1', '1', '0324', '2018-08-03', '0', '2018-08-12 12:55:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('2', '2', '0324', '2018-08-03', '0', '2018-08-12 12:56:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('3', '3', '0324', '2018-08-03', '0', '2018-08-12 12:56:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('4', '4', '0324', '2018-08-03', '0', '2018-08-12 12:56:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('5', '5', '0324', '2018-08-03', '0', '2018-08-12 12:56:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('6', '6', '0324', '2018-08-03', '0', '2018-08-12 12:57:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('7', '7', '0324', '2018-08-03', '0', '2018-08-12 12:57:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('8', '8', '0324', '2018-08-03', '0', '2018-08-12 12:57:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('9', '9', '0324', '2018-08-03', '0', '2018-08-12 12:57:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('10', '10', '0324', '2018-08-03', '0', '2018-08-12 12:57:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('11', '11', '0324', '2018-08-03', '0', '2018-08-12 12:55:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('12', '12', '0324', '2018-08-03', '0', '2018-08-12 12:58:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('13', '13', '324', '2018-08-07', '0', '2018-08-07 18:10:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('14', '14', '0324', '2018-08-07', '0', '2018-08-07 18:15:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('15', '15', '0324', '2018-08-07', '0', '2018-08-07 18:19:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('16', '16', '0324', '2018-08-07', '0', '2018-08-07 18:38:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('17', '17', '0324', '2018-08-08', '0', '2018-08-08 10:33:35');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('18', '18', '0324', '2018-08-08', '0', '2018-08-08 10:40:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('19', '19', '0324', '2018-08-08', '0', '2018-08-08 16:07:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('20', '20', '0324', '2018-08-08', '0', '2018-08-08 16:09:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('21', '21', '3510', '2018-08-13', '0', '2018-08-13 11:51:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('22', '21', '0324', '2018-08-13', '0', '2018-08-13 11:51:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('23', '6', '6089', '2018-08-13', '0', '2018-08-13 12:01:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('24', '9', '0576', '2018-08-14', '0', '2018-08-14 11:11:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('25', '4', '9705', '2018-08-14', '0', '2018-08-14 11:13:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('26', '20', '9705', '2018-08-14', '0', '2018-08-14 11:16:46');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('27', '20', '3510', '2018-08-14', '0', '2018-08-14 11:17:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('28', '13', '0324', '2018-08-18', '0', '2018-08-18 10:48:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('29', '22', '0324', '2018-08-18', '0', '2018-08-18 11:32:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('30', '11', '4233', '2018-08-20', '0', '2018-08-20 14:34:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('31', '4', '0825', '2018-08-30', '0', '2018-08-30 16:19:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('32', '23', '1463', '2018-09-01', '0', '2018-09-01 11:37:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('33', '23', '8887', '2018-09-01', '0', '2018-09-01 11:39:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('34', '24', '0825', '2018-09-01', '0', '2018-09-01 11:45:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('35', '25', '4683', '2018-09-01', '0', '2018-09-01 11:47:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('36', '26', '1543', '2018-09-01', '0', '2018-09-01 11:49:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('37', '27', '2253', '2018-09-01', '0', '2018-09-01 11:52:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('38', '29', '3716', '2018-09-01', '0', '2018-09-01 11:56:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('39', '26', '2641', '2018-09-01', '0', '2018-09-01 12:00:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('40', '30', 'TRALI', '2018-09-01', '0', '2018-09-01 12:08:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('41', '23', '0221', '2018-09-01', '0', '2018-09-01 12:12:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('42', '31', '6089', '2018-09-01', '0', '2018-09-01 12:21:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('43', '32', '7238', '2018-09-01', '0', '2018-09-01 16:39:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('44', '32', '9705', '2018-09-01', '0', '2018-09-01 16:39:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('45', '24', '4233', '2018-09-01', '0', '2018-09-01 16:41:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('46', '25', '7707', '2018-09-01', '0', '2018-09-01 16:44:21');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('47', '33', '0207', '2018-09-01', '0', '2018-09-01 16:57:27');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('48', '34', '8669', '2018-09-02', '0', '2018-09-02 11:46:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('49', '23', '1251', '2018-09-02', '0', '2018-09-02 11:53:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('50', '26', '2103', '2018-09-02', '0', '2018-09-02 11:54:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('51', '26', '1752', '2018-09-02', '0', '2018-09-02 11:56:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('52', '35', '3510', '2018-09-02', '0', '2018-09-02 12:16:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('53', '35', '0324', '2018-09-02', '0', '2018-09-02 12:16:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('54', '26', '0809', '2018-09-02', '0', '2018-09-02 12:30:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('55', '36', '4311', '2018-09-03', '0', '2018-09-03 12:12:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('56', '37', '1783', '2018-09-03', '0', '2018-09-03 12:28:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('57', '38', '1385', '2018-09-03', '0', '2018-09-03 12:32:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('58', '39', 'trali', '2018-09-06', '0', '2018-09-06 14:56:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('59', '40', '3510', '2018-09-06', '0', '2018-09-06 15:06:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('60', '20', '6631', '2018-09-07', '0', '2018-09-07 14:47:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('61', '30', '9111', '2018-09-07', '0', '2018-09-07 15:42:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('62', '38', '6199', '2018-09-07', '0', '2018-09-07 15:45:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('63', '32', '0825', '2018-09-07', '0', '2018-09-07 15:53:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('64', '26', '0230', '2018-09-08', '0', '2018-09-08 15:50:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('65', '6', '576', '2018-09-10', '0', '2018-09-10 12:57:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('66', '11', '0576', '2018-09-10', '0', '2018-09-10 13:04:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('67', '11', '6089', '2018-09-10', '0', '2018-09-10 13:06:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('68', '15', '0576', '2018-09-10', '0', '2018-09-10 13:07:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('69', '15', '6089', '2018-09-10', '0', '2018-09-10 13:08:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('70', '17', '0825', '2018-09-11', '0', '2018-09-11 12:16:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('71', '30', '5106', '2018-09-11', '0', '2018-09-11 12:20:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('72', '32', '3716', '2018-09-11', '0', '2018-09-11 12:25:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('73', '30', '0834', '2018-09-11', '0', '2018-09-11 12:39:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('74', '41', '0324', '2018-09-11', '0', '2018-09-11 12:42:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('75', '11', '1783', '2018-09-13', '0', '2018-09-13 14:46:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('76', '42', '0324', '2018-09-15', '0', '2018-09-15 15:25:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('77', '11', '0221', '2018-09-15', '0', '2018-09-15 15:39:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('78', '26', '2182', '2018-09-15', '0', '2018-09-15 15:42:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('79', '40', '0576', '2018-09-18', '0', '2018-09-18 10:38:32');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('80', '4', '1752', '2018-09-18', '0', '2018-09-18 11:11:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('81', '43', '2804', '2018-09-18', '0', '2018-09-18 14:47:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('82', '11', '0825', '2018-09-18', '0', '2018-09-18 14:54:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('83', '43', '4612', '2018-09-18', '0', '2018-09-18 15:02:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('84', '3', '0221', '2018-09-20', '0', '2018-09-20 13:44:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('85', '44', '6199', '2018-09-21', '0', '2018-09-21 09:38:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('86', '24', '0324', '2018-09-21', '0', '2018-09-21 16:19:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('87', '16', '6089', '2018-09-24', '0', '2018-09-24 15:36:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('88', '21', '0576', '2018-09-24', '0', '2018-09-24 15:43:18');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('89', '3', '6089', '2018-09-25', '0', '2018-09-25 15:05:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('90', '35', '0576', '2018-09-25', '0', '2018-09-25 15:13:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('91', '19', '6089', '2018-09-26', '0', '2018-09-26 14:46:22');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('92', '2', '7238', '2018-09-26', '0', '2018-09-26 14:58:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('93', '11', '7238', '2018-09-27', '0', '2018-09-27 15:50:24');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('94', '45', '2704', '2018-09-29', '0', '2018-09-29 15:53:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('95', '3', '7238', '2018-09-30', '0', '2018-09-30 15:42:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('96', '46', '3510', '2018-09-30', '0', '2018-09-30 15:47:24');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('97', '46', '0324', '2018-09-30', '0', '2018-09-30 15:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('98', '47', '0324', '2018-10-01', '0', '2018-10-01 15:30:29');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('99', '48', '3510', '2018-10-01', '0', '2018-10-01 15:44:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('100', '4', '0221', '2018-10-02', '0', '2018-10-02 15:25:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('101', '13', '3714', '2018-10-03', '0', '2018-10-03 15:05:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('102', '11', '3716', '2018-10-04', '0', '2018-10-04 15:48:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('103', '32', '8589', '2018-10-06', '0', '2018-10-06 15:08:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('104', '49', '0948', '2018-10-07', '0', '2018-10-07 15:14:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('105', '50', '2454', '2018-10-07', '0', '2018-10-07 15:41:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('106', '34', '0669', '2018-10-07', '0', '2018-10-07 15:51:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('107', '3', '1785', '2018-10-10', '0', '2018-10-10 16:06:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('108', '29', '0324', '2018-10-11', '0', '2018-10-11 16:21:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('109', '45', '3580', '2018-10-11', '0', '2018-10-11 16:32:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('110', '51', '2454', '2018-10-12', '0', '2018-10-12 09:49:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('111', '13', '0825', '2018-10-12', '0', '2018-10-12 17:04:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('112', '17', '3716', '2018-10-13', '0', '2018-10-13 15:31:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('113', '3', '0825', '2018-10-15', '0', '2018-10-15 15:58:37');


