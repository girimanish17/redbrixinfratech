#
# TABLE STRUCTURE FOR: bills
#

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `bill_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `due` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `tax_amount` int(11) NOT NULL,
  `diposit_amount` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('1', 'sampat', '8602442648', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:09:12');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('2', 'maze buildcon', '1111111111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:26:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('3', 'sayta', '1011111111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:28:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('4', 'sardar ji', '1234567011', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:30:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('5', 'gangotri ', '1200311111', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:31:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('6', 'gaurav jain', '2222000002', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:32:21');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('7', 'desai ji', '3333333333', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:33:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('8', 'hebal som', '3333333331', 'khndwa road indore m.p', '2018-08-03', '0', '2018-08-03 10:41:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('9', 'singhl sahb', '1110000007', 'indore m.p', '2018-08-03', '0', '2018-08-03 10:42:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('10', 'mukesh prajapat', '9827250327', 'indore m.p', '2018-08-03', '0', '2018-08-03 11:10:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('11', 'makhija ji', '5555555555', 'indore m.p', '2018-08-03', '0', '2018-08-03 11:15:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('12', 'natraj tiles', '6666666666', 'indore m.p', '2018-08-03', '0', '2018-08-03 14:26:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('13', 'badwani ji', '1000001112', 'khndwa road indore', '2018-08-07', '0', '2018-08-07 18:10:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('14', 'ultra tech', '4444440909', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:15:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('15', 'kukreja ji', '7070708888', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:19:17');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('16', 'jk buildcon', '1010101010', 'indore m.p', '2018-08-07', '0', '2018-08-07 18:37:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('17', 'parsawnath ji', '8989898980', 'indore m.p', '2018-08-08', '0', '2018-08-08 10:33:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('18', 'jai baba', '7030500005', 'indore m.p', '2018-08-08', '0', '2018-08-08 10:39:53');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('19', 'ML AGARWAL SCHOOL', '6565656565', 'INDORE MP', '2018-08-08', '0', '2018-08-08 16:06:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('20', 'kapil pariya', '5050505060', 'indore mp', '2018-08-08', '0', '2018-08-08 16:09:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('21', 'capital', '7676767687', 'brg indore', '2018-08-13', '0', '2018-08-13 11:50:57');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('22', 'umriya bricks factory', '5454545454', 'indore umriya', '2018-08-18', '0', '2018-08-18 11:32:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('23', 'D S', '1010203030', 'INDORE M.P', '2018-09-01', '0', '2018-09-01 11:36:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('24', 'RM', '9999999998', 'INDORE', '2018-09-01', '0', '2018-09-01 11:44:47');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('25', 'ARJUN JAT', '2222111134', 'INDORE', '2018-09-01', '0', '2018-09-01 11:46:57');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('26', 'PANKAJ MAKHIJA', '9898765432', 'INDORE', '2018-09-01', '0', '2018-09-01 11:49:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('27', 'SHER SINGH', '1212121234', 'INDORE', '2018-09-01', '0', '2018-09-01 11:51:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('28', '892', '8787690901', 'INDORE', '2018-09-01', '0', '2018-09-01 11:55:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('29', 'BANTY RAWLIYA', '3456783490', 'INDORE', '2018-09-01', '0', '2018-09-01 11:56:35');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('30', 'CASH', '0909090909', 'INDORE', '2018-09-01', '0', '2018-09-01 12:07:33');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('31', 'PL', '1212347890', 'INDORE', '2018-09-01', '0', '2018-09-01 12:20:37');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('32', 'ms', '4563217890', 'indore', '2018-09-01', '0', '2018-09-01 16:38:45');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('33', 'CHNDU', '9898765431', 'INDORE', '2018-09-01', '0', '2018-09-01 16:57:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('34', 'narendra khndwal', '6767890564', 'indore', '2018-09-02', '0', '2018-09-02 11:45:55');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('35', 'KAPIL PARIYA 8 MIL', '2323456781', 'INDORE', '2018-09-02', '0', '2018-09-02 12:16:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('36', 'sanny jat', '8787906547', 'indore', '2018-09-03', '0', '2018-09-03 12:11:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('37', 'RAHUL', '9807654321', 'INDORE', '2018-09-03', '0', '2018-09-03 12:28:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('38', 'SEWAK RAM', '8888899999', 'INDORE', '2018-09-03', '0', '2018-09-03 12:32:24');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('39', 'lakhn jat', '0909090901', 'indore', '2018-09-06', '0', '2018-09-06 14:55:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('40', 'sunil sheth', '4545678632', 'indore', '2018-09-06', '0', '2018-09-06 15:06:22');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('41', 'MAHESH PATIDAR', '8976543214', 'INDORE', '2018-09-11', '0', '2018-09-11 12:42:00');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('42', 'goyal sahab', '5678432103', 'indore mp', '2018-09-15', '0', '2018-09-15 15:24:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('43', 'mangesh yadav', '9080706054', 'indore mp', '2018-09-18', '0', '2018-09-18 14:46:58');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('44', 'shiv ram', '6070805432', 'indore mp', '2018-09-21', '0', '2018-09-21 09:38:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('45', 'sanjay khndewal', '9712309875', 'indore', '2018-09-29', '0', '2018-09-29 15:52:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('46', 'pahuja ji 8 mil', '9087654321', 'INDORE', '2018-09-30', '0', '2018-10-01 15:14:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('47', 'Lokesh ji ', '1029304059', 'indore mp', '2018-10-01', '0', '2018-10-01 15:30:10');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('48', 'Trilok poltri farm', '3040501065', 'indore mp', '2018-10-01', '0', '2018-10-01 15:44:03');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('49', 'DARWAR', '8123123456', 'INDORE', '2018-10-07', '0', '2018-10-07 15:14:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('50', 'MONU ARORA', '2134333333', 'INDORE', '2018-10-07', '0', '2018-10-07 15:40:45');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('51', 'manu arora', '9870984563', 'indore', '2018-10-12', '0', '2018-10-12 09:48:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('52', 'rajesh agarwal', '9870004423', 'indore', '2018-10-29', '0', '2018-10-29 12:16:55');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('53', 'bheem darwar', '6060789045', 'indore', '2018-10-29', '0', '2018-10-29 12:29:00');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('54', 'RAJESH AGARWAL', '7098009987', 'INDORE', '2018-11-05', '1', '2018-11-05 10:57:33');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('55', 'yadav ji bambe  hospital', '5123098645', 'indore', '2018-11-14', '0', '2018-11-14 16:14:31');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('56', 'UJJAWAL KHURANA', '8933445567', 'INDORE', '2018-11-18', '0', '2018-11-18 15:48:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('57', 'kishor chudhry', '9888977765', 'indore', '2018-11-20', '0', '2018-11-20 14:52:44');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('58', 'jeevan', '9876678954', 'indore', '2018-11-22', '0', '2018-11-22 16:34:09');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('59', 'syam agarwal', '8763355123', 'indore', '2018-12-06', '0', '2018-12-06 12:21:31');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('60', 'rajendra renuka dhaba', '4563289990', 'indore', '2018-12-10', '0', '2018-12-10 15:42:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('61', 'sunita jagdis khndelwal', '2233445500', 'indore', '2018-12-15', '0', '2018-12-15 14:54:46');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('62', 'rajesh jindal', '5674399876', 'indore', '2018-12-17', '0', '2018-12-17 16:47:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('63', 'vijay agarwal', '9876543290', 'indore', '2018-12-17', '0', '2018-12-17 16:51:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('64', 'omaxe city', '4456789033', 'indore', '2018-12-22', '0', '2018-12-22 16:33:32');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('65', 'DPS', '8765431234', 'INDORE', '2018-12-23', '0', '2018-12-23 15:00:54');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('66', 'amit aary', '3330098776', 'indore', '2018-12-28', '0', '2018-12-28 13:30:01');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('67', 'harsh agarwal', '1123456789', 'indore', '2018-12-28', '0', '2018-12-28 16:55:26');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('68', 'mohit and company', '4321111222', 'indore', '2018-12-29', '0', '2018-12-29 15:22:44');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('69', 'mhadev tiles', '1112345635', 'indore', '2018-12-30', '0', '2018-12-30 16:38:48');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('70', 'mahadev tiles', '1123433491', 'indore', '2018-12-30', '0', '2018-12-30 16:40:22');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('71', 'MALWA COLLAGE SURENDRA JI', '1102345634', 'INDORE', '2019-01-02', '0', '2019-01-02 15:33:42');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('72', 'SANTOSH BY PASS', '2134521342', 'INDORE', '2019-01-02', '0', '2019-01-02 15:44:03');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('73', 'jethanand', '9098765439', 'indore', '2019-01-04', '0', '2019-01-04 10:10:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('74', 'kumawat ji', '1112223321', 'indore', '2019-01-12', '0', '2019-01-12 17:02:41');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('75', 'kasturiya ji', '9807654366', 'indore', '2019-01-12', '0', '2019-01-12 17:10:29');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('76', 'jai mata di', '1234123345', 'indore', '2019-02-02', '0', '2019-02-02 16:11:35');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('77', 'stp jk', '0909090902', 'indore', '2019-02-09', '0', '2019-02-09 16:19:05');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('78', 'manish pandit', '3322114556', 'indore', '2019-03-09', '0', '2019-03-09 17:32:10');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('79', 'pramanand ji', '9852838533', 'indore', '2019-03-24', '0', '2019-03-24 11:13:12');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('80', 'super rmc plant', '9090888909', 'indore', '2019-04-12', '0', '2019-04-12 16:48:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('81', 'hitesh ji', '9807690321', 'indore', '2019-06-07', '0', '2019-06-07 18:09:12');


#
# TABLE STRUCTURE FOR: dues
#

DROP TABLE IF EXISTS `dues`;

CREATE TABLE `dues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: gate_pass
#

DROP TABLE IF EXISTS `gate_pass`;

CREATE TABLE `gate_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` varchar(250) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `client_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=latin1;

INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('1', '493', '2019-08-02', '00:00 AM', '00:00 AM', '29', '38', '2', '4', '0', '', '2019-08-02', '2019-08-02 15:38:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('2', '494', '2019-08-02', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-02', '2019-08-02 15:38:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('3', '495', '2019-08-02', '00:00 AM', '00:00 AM', '24', '45', '3', '9', '0', '', '2019-08-02', '2019-08-02 15:39:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('4', '496', '2019-08-02', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-02', '2019-08-02 15:40:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('5', '497', '2019-08-02', '00:00 AM', '00:00 AM', '4', '158', '3', '10', '0', '', '2019-08-02', '2019-08-02 15:44:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('6', '498', '2019-08-02', '00:00 AM', '00:00 AM', '20', '60', '3', '9', '0', '', '2019-08-02', '2019-08-02 15:45:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('7', '499', '2019-08-02', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2019-08-02', '2019-08-02 15:46:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('8', '500', '2019-08-02', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '0', '', '2019-08-02', '2019-08-02 15:46:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('9', '501', '2019-08-02', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-08-02', '2019-08-02 15:47:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('10', '502', '2019-08-02', '00:00 AM', '00:00 AM', '4', '158', '2', '10', '0', '', '2019-08-02', '2019-08-02 15:47:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('11', '503', '2019-08-02', '00:00 AM', '00:00 AM', '23', '49', '3', '9', '0', '', '2019-08-02', '2019-08-02 15:48:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('12', '504', '2019-08-02', '00:00 AM', '00:00 AM', '32', '43', '7', '10', '0', '', '2019-08-02', '2019-08-02 15:49:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('13', '505', '2019-08-02', '00:00 AM', '00:00 AM', '9', '9', '3', '22', '0', '', '2019-08-02', '2019-08-02 15:49:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('14', '506', '2019-08-02', '00:00 AM', '00:00 AM', '30', '40', '9', '9', '0', '', '2019-08-02', '2019-08-02 15:50:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('15', '507', '2019-08-02', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-02', '2019-08-02 15:50:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('16', '508', '2019-08-02', '00:00 AM', '00:00 AM', '53', '119', '9', '9', '0', '', '2019-08-02', '2019-08-02 15:51:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('17', '509', '2019-08-02', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-02', '2019-08-02 15:51:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('18', '510', '2019-08-02', '00:00 AM', '00:00 AM', '4', '158', '2', '10', '0', '', '2019-08-02', '2019-08-02 15:52:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('19', '511', '2019-08-02', '00:00 AM', '00:00 AM', '53', '121', '1', '4', '0', '', '2019-08-02', '2019-08-02 15:52:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('20', '512', '2019-08-02', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2019-08-02', '2019-08-02 15:53:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('21', '513', '2019-08-02', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '0', '', '2019-08-02', '2019-08-02 15:53:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('22', '514', '2019-08-02', '00:00 AM', '00:00 AM', '23', '49', '2', '9', '0', '', '2019-08-02', '2019-08-02 15:54:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('23', '515', '2019-08-02', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-08-02', '2019-08-02 15:54:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('24', '516', '2019-08-02', '00:00 AM', '00:00 AM', '26', '54', '3', '9', '0', '', '2019-08-02', '2019-08-02 15:55:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('25', '517', '2019-08-02', '00:00 AM', '00:00 AM', '30', '40', '9', '9', '0', '', '2019-08-02', '2019-08-02 15:56:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('26', '518', '2019-08-02', '00:00 AM', '00:00 AM', '4', '4', '3', '22', '0', '', '2019-08-02', '2019-08-02 15:56:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('27', '519', '2019-08-02', '00:00 AM', '00:00 AM', '4', '158', '3', '10', '0', '', '2019-08-02', '2019-08-02 15:59:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('28', '520', '2019-08-02', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-08-02', '2019-08-02 16:00:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('29', '521', '2019-08-02', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-08-02', '2019-08-02 16:00:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('30', '522', '2019-08-02', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-02', '2019-08-02 16:01:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('31', '523', '2019-08-02', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-03', '2019-08-03 13:42:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('32', '524', '2019-08-02', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-08-03', '2019-08-03 13:43:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('33', '525', '2019-08-02', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-08-03', '2019-08-03 13:43:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('34', '527', '2019-08-02', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-08-03', '2019-08-03 13:44:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('35', '528', '2019-08-02', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-08-03', '2019-08-03 13:44:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('36', '529', '2019-08-02', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-08-03', '2019-08-03 13:45:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('37', '530', '2019-08-02', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-03', '2019-08-03 13:45:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('38', '531', '2019-08-02', '00:00 AM', '00:00 AM', '11', '11', '3', '22', '0', '', '2019-08-03', '2019-08-03 13:46:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('39', '532', '2019-08-02', '00:00 AM', '00:00 AM', '26', '54', '3', '10', '0', '', '2019-08-03', '2019-08-03 14:54:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('40', '533', '2019-08-03', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-08-03', '2019-08-03 14:54:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('41', '534', '2019-08-03', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-08-03', '2019-08-03 14:55:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('42', '535', '2019-08-03', '00:00 AM', '00:00 AM', '53', '119', '7', '9', '0', '', '2019-08-03', '2019-08-03 14:56:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('43', '537', '2019-08-03', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-08-03', '2019-08-03 14:57:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('44', '538', '2019-08-03', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-08-03', '2019-08-03 14:57:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('45', '539', '2019-08-03', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-08-03', '2019-08-03 14:58:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('46', '540', '2019-08-03', '00:00 AM', '00:00 AM', '4', '158', '3', '10', '0', '', '2019-08-03', '2019-08-03 14:59:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('47', '542', '2019-08-03', '00:00 AM', '00:00 AM', '20', '60', '3', '9', '0', '', '2019-08-03', '2019-08-03 15:00:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('48', '543', '2019-08-03', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-03', '2019-08-03 15:02:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('49', '544', '2019-08-03', '00:00 AM', '00:00 AM', '26', '166', '1', '20', '0', '', '2019-08-03', '2019-08-03 15:02:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('50', '545', '2019-08-03', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-08-03', '2019-08-03 15:05:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('51', '546', '2019-08-03', '00:00 AM', '00:00 AM', '53', '121', '3', '5', '0', '', '2019-08-03', '2019-08-03 15:06:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('52', '547', '2019-08-03', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-03', '2019-08-03 15:09:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('53', '549', '2019-08-03', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-08-03', '2019-08-03 15:10:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('54', '550', '2019-08-03', '00:00 AM', '00:00 AM', '26', '64', '3', '9', '0', '', '2019-08-03', '2019-08-03 15:13:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('55', '551', '2019-08-03', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '0', '', '2019-08-03', '2019-08-03 15:13:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('56', '552', '2019-08-03', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-08-03', '2019-08-03 15:14:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('57', '553', '2019-08-03', '00:00 AM', '00:00 AM', '4', '4', '3', '22', '0', '', '2019-08-03', '2019-08-03 15:14:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('58', '554', '2019-08-03', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-08-03', '2019-08-03 15:15:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('59', '555', '2019-08-03', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-08-03', '2019-08-03 15:16:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('60', '556', '2019-08-03', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-08-03', '2019-08-03 15:16:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('61', '557', '2019-08-03', '00:00 AM', '00:00 AM', '46', '144', '1', '10', '0', '', '2019-08-03', '2019-08-03 15:17:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('62', '558', '2019-08-03', '00:00 AM', '00:00 AM', '9', '163', '3', '10', '0', '', '2019-08-03', '2019-08-03 15:18:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('63', '559', '2019-08-03', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-03', '2019-08-03 15:19:31');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('64', '560', '2019-08-03', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '0', '', '2019-08-03', '2019-08-03 15:19:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('65', '561', '2019-08-03', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-08-03', '2019-08-03 15:20:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('66', '562', '2019-08-03', '00:00 AM', '00:00 AM', '26', '54', '3', '9', '0', '', '2019-08-03', '2019-08-03 15:21:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('67', '563', '2019-08-03', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-03', '2019-08-03 18:05:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('68', '564', '2019-08-03', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-03', '2019-08-03 18:05:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('69', '565', '2019-08-03', '00:00 AM', '00:00 AM', '45', '109', '1', '10', '0', '', '2019-08-03', '2019-08-03 18:06:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('70', '567', '2019-08-03', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-08-03', '2019-08-03 18:06:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('71', '568', '2019-08-03', '00:00 AM', '00:00 AM', '31', '42', '1', '10', '0', '', '2019-08-03', '2019-08-03 18:07:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('72', '569', '2019-08-03', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-08-03', '2019-08-03 18:08:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('73', '570', '2019-08-03', '00:00 AM', '00:00 AM', '11', '11', '9', '22', '0', '', '2019-08-04', '2019-08-04 13:48:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('74', '571', '2019-08-03', '00:00 AM', '00:00 AM', '31', '42', '3', '10', '0', '', '2019-08-04', '2019-08-04 13:49:05');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('75', '572', '2019-08-03', '00:00 AM', '00:00 AM', '31', '42', '1', '10', '0', '', '2019-08-04', '2019-08-04 13:49:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('76', '574', '2019-08-03', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-04', '2019-08-04 13:50:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('77', '575', '2019-08-03', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-08-04', '2019-08-04 13:50:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('78', '576', '2019-08-03', '00:00 AM', '00:00 AM', '11', '11', '3', '22', '0', '', '2019-08-04', '2019-08-04 13:51:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('79', '577', '2019-08-04', '00:00 AM', '00:00 AM', '23', '32', '2', '4', '0', '', '2019-08-04', '2019-08-04 13:52:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('80', '578', '2019-08-04', '00:00 AM', '00:00 AM', '38', '57', '1', '9', '0', '', '2019-08-04', '2019-08-04 13:52:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('81', '579', '2019-08-04', '00:00 AM', '00:00 AM', '23', '49', '9', '9', '0', '', '2019-08-04', '2019-08-04 13:57:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('82', '580', '2019-08-04', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '0', '', '2019-08-04', '2019-08-04 13:58:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('83', '581', '2019-08-04', '00:00 AM', '00:00 AM', '53', '119', '1', '9', '0', '', '2019-08-04', '2019-08-04 13:59:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('84', '582', '2019-08-04', '00:00 AM', '00:00 AM', '29', '38', '2', '4', '0', '', '2019-08-04', '2019-08-04 14:02:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('85', '583', '2019-08-04', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-08-04', '2019-08-04 14:02:42');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('86', '584', '2019-08-04', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-08-04', '2019-08-04 14:03:10');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('87', '585', '2019-08-04', '00:00 AM', '00:00 AM', '11', '161', '7', '10', '0', '', '2019-08-04', '2019-08-04 14:04:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('88', '586', '2019-08-04', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-08-04', '2019-08-04 14:04:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('89', '587', '2019-08-04', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-08-04', '2019-08-04 14:05:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('90', '589', '2019-08-04', '00:00 AM', '00:00 AM', '26', '78', '2', '10', '0', '', '2019-08-04', '2019-08-04 14:07:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('91', '590', '2019-08-04', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-04', '2019-08-04 14:08:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('92', '591', '2019-08-04', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-08-04', '2019-08-04 14:09:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('93', '592', '2019-08-04', '00:00 AM', '00:00 AM', '22', '29', '3', '22', '0', '', '2019-08-04', '2019-08-04 14:09:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('94', '593', '2019-08-04', '00:00 AM', '00:00 AM', '26', '64', '3', '9', '0', '', '2019-08-04', '2019-08-04 14:10:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('95', '594', '2019-08-04', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-08-04', '2019-08-04 14:11:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('96', '595', '2019-08-04', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-04', '2019-08-04 16:56:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('97', '596', '2019-08-04', '00:00 AM', '00:00 AM', '24', '34', '1', '9', '0', '', '2019-08-04', '2019-08-04 16:56:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('98', '597', '2019-08-04', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-08-04', '2019-08-04 16:57:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('99', '598', '2019-08-04', '00:00 AM', '00:00 AM', '9', '163', '3', '10', '0', '', '2019-08-04', '2019-08-04 16:57:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('100', '599', '2019-08-04', '00:00 AM', '00:00 AM', '27', '37', '1', '4', '0', '', '2019-08-04', '2019-08-04 16:58:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('101', '600', '2019-08-04', '00:00 AM', '00:00 AM', '53', '121', '1', '4', '0', '', '2019-08-04', '2019-08-04 16:58:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('102', '601', '2019-08-04', '00:00 AM', '00:00 AM', '9', '9', '3', '22', '0', '', '2019-08-04', '2019-08-04 16:59:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('103', '602', '2019-08-04', '00:00 AM', '00:00 AM', '30', '40', '1', '2', '0', '', '2019-08-04', '2019-08-04 16:59:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('104', '603', '2019-08-04', '00:00 AM', '00:00 AM', '11', '161', '7', '10', '0', '', '2019-08-04', '2019-08-04 17:01:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('105', '604', '2019-08-04', '00:00 AM', '00:00 AM', '45', '109', '9', '10', '0', '', '2019-08-04', '2019-08-04 17:02:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('106', '606', '2019-08-04', '00:00 AM', '00:00 AM', '11', '161', '1', '10', '0', '', '2019-08-06', '2019-08-06 11:12:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('107', '607', '2019-08-04', '00:00 AM', '00:00 AM', '53', '121', '1', '4', '0', '', '2019-08-06', '2019-08-06 11:12:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('108', '608', '2019-08-04', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-08-06', '2019-08-06 11:13:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('109', '609', '2019-08-04', '00:00 AM', '00:00 AM', '47', '98', '1', '22', '0', '', '2019-08-06', '2019-08-06 11:14:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('110', '610', '2019-08-04', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '0', '', '2019-08-06', '2019-08-06 11:15:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('111', '611', '2019-08-04', '00:00 AM', '00:00 AM', '26', '54', '3', '9', '0', '', '2019-08-06', '2019-08-06 11:16:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('112', '612', '2019-08-04', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '0', '', '2019-08-06', '2019-08-06 11:17:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('113', '613', '2019-08-04', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-08-06', '2019-08-06 11:18:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('114', '614', '2019-08-04', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '0', '', '2019-08-06', '2019-08-06 11:18:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('115', '615', '2019-08-04', '00:00 AM', '00:00 AM', '26', '54', '1', '9', '0', '', '2019-08-06', '2019-08-06 11:19:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('116', '616', '2019-08-06', '00:00 AM', '00:00 AM', '6', '6', '3', '22', '0', '', '2019-08-06', '2019-08-06 11:20:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('117', '617', '2019-08-06', '00:00 AM', '00:00 AM', '25', '35', '1', '9', '0', '', '2019-08-06', '2019-08-06 11:20:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('118', '618', '2019-08-06', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-06', '2019-08-06 11:21:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('119', '619', '2019-08-06', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-06', '2019-08-06 11:21:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('120', '620', '2019-08-06', '00:00 AM', '00:00 AM', '24', '45', '3', '9', '0', '', '2019-08-06', '2019-08-06 11:22:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('121', '621', '2019-08-06', '00:00 AM', '00:00 AM', '29', '38', '1', '5', '0', '', '2019-08-06', '2019-08-06 11:23:04');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('122', '622', '2019-08-06', '00:00 AM', '00:00 AM', '38', '57', '1', '9', '0', '', '2019-08-06', '2019-08-06 11:23:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('123', '623', '2019-08-06', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-08-06', '2019-08-06 11:24:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('124', '625', '2019-08-06', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-08-06', '2019-08-06 15:27:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('125', '626', '2019-08-06', '00:00 AM', '00:00 AM', '32', '43', '2', '10', '0', '', '2019-08-06', '2019-08-06 15:28:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('126', '627', '2019-08-06', '00:00 AM', '00:00 AM', '44', '85', '1', '9', '0', '', '2019-08-06', '2019-08-06 15:28:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('127', '628', '2019-08-06', '00:00 AM', '00:00 AM', '45', '94', '9', '15', '0', '', '2019-08-06', '2019-08-06 15:29:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('128', '629', '2019-08-06', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2019-08-06', '2019-08-06 15:29:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('129', '630', '2019-08-06', '00:00 AM', '00:00 AM', '27', '37', '3', '4', '0', '', '2019-08-06', '2019-08-06 15:30:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('130', '631', '2019-08-06', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-08-06', '2019-08-06 16:48:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('131', '632', '2019-08-06', '00:00 AM', '00:00 AM', '23', '49', '1', '9', '0', '', '2019-08-06', '2019-08-06 16:49:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('132', '633', '2019-08-06', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-06', '2019-08-06 16:50:05');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('133', '634', '2019-08-06', '00:00 AM', '00:00 AM', '47', '98', '1', '22', '0', '', '2019-08-06', '2019-08-06 16:50:39');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('134', '636', '2019-08-06', '00:00 AM', '00:00 AM', '38', '57', '3', '9', '0', '', '2019-08-06', '2019-08-06 16:51:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('135', '637', '2019-08-06', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2019-08-06', '2019-08-06 16:57:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('136', '638', '2019-08-06', '00:00 AM', '00:00 AM', '29', '38', '1', '4', '0', '', '2019-08-06', '2019-08-06 16:58:39');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('137', '639', '2019-08-06', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-06', '2019-08-06 16:59:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('138', '640', '2019-08-06', '00:00 AM', '00:00 AM', '20', '60', '8', '9', '0', '', '2019-08-06', '2019-08-06 17:11:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('139', '641', '2019-08-06', '00:00 AM', '00:00 AM', '38', '57', '1', '9', '0', '', '2019-08-06', '2019-08-06 17:12:19');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('140', '642', '2019-08-06', '00:00 AM', '00:00 AM', '23', '32', '3', '4', '0', '', '2019-08-06', '2019-08-06 17:12:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('141', '643', '2019-08-06', '00:00 AM', '00:00 AM', '31', '42', '3', '9', '0', '', '2019-08-06', '2019-08-06 17:13:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('142', '644', '2019-08-06', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-06', '2019-08-06 17:13:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('143', '646', '2019-08-06', '00:00 AM', '00:00 AM', '32', '235', '3', '9', '0', '', '2019-08-08', '2019-08-08 12:06:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('144', '647', '2019-08-06', '00:00 AM', '00:00 AM', '5', '5', '3', '16', '0', '', '2019-08-08', '2019-08-08 12:09:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('145', '648', '2019-08-06', '00:00 AM', '00:00 AM', '58', '141', '3', '4', '0', '', '2019-08-08', '2019-08-08 12:09:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('146', '649', '2019-08-06', '00:00 AM', '00:00 AM', '31', '42', '3', '9', '0', '', '2019-08-08', '2019-08-08 12:10:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('147', '650', '2019-08-06', '00:00 AM', '00:00 AM', '31', '42', '1', '9', '0', '', '2019-08-08', '2019-08-08 12:10:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('148', '651', '2019-08-06', '00:00 AM', '00:00 AM', '11', '11', '9', '22', '0', '', '2019-08-08', '2019-08-08 12:11:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('149', '652', '2019-08-06', '00:00 AM', '00:00 AM', '26', '54', '1', '9', '0', '', '2019-08-08', '2019-08-08 12:12:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('151', '653', '2019-08-06', '00:00 AM', '00:00 AM', '58', '141', '1', '4', '0', '', '2019-08-08', '2019-08-08 12:14:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('152', '654', '2019-08-06', '00:00 AM', '00:00 AM', '41', '233', '3', '9', '0', '', '2019-08-08', '2019-08-08 12:15:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('153', '655', '2019-08-06', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-08-08', '2019-08-08 12:15:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('154', '656', '2019-08-06', '00:00 AM', '00:00 AM', '58', '141', '2', '4', '0', '', '2019-08-08', '2019-08-08 12:16:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('155', '657', '2019-08-06', '00:00 AM', '00:00 AM', '26', '54', '1', '10', '0', '', '2019-08-08', '2019-08-08 12:16:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('156', '658', '2019-08-06', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2019-08-08', '2019-08-08 12:17:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('157', '659', '2019-08-06', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2019-08-08', '2019-08-08 12:18:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('158', '659', '2019-08-06', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2019-08-08', '2019-08-08 12:18:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('159', '660', '2019-08-07', '00:00 AM', '00:00 AM', '30', '40', '1', '9', '0', '', '2019-08-08', '2019-08-08 12:19:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('160', '661', '2019-08-07', '00:00 AM', '00:00 AM', '23', '32', '1', '4', '0', '', '2019-08-08', '2019-08-08 12:20:09');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('161', '662', '2019-08-07', '00:00 AM', '00:00 AM', '45', '94', '9', '15', '0', '', '2019-08-08', '2019-08-08 12:20:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('162', '663', '2019-08-07', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '0', '', '2019-08-08', '2019-08-08 12:21:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('163', '664', '2019-08-07', '00:00 AM', '00:00 AM', '32', '43', '1', '10', '0', '', '2019-08-08', '2019-08-08 12:21:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('164', '666', '2019-08-07', '00:00 AM', '00:00 AM', '81', '224', '9', '22', '0', '', '2019-08-08', '2019-08-08 12:23:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('165', '667', '2019-08-07', '00:00 AM', '00:00 AM', '26', '78', '1', '12', '0', '', '2019-08-08', '2019-08-08 12:23:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('166', '668', '2019-08-07', '00:00 AM', '00:00 AM', '32', '43', '3', '10', '0', '', '2019-08-08', '2019-08-08 12:24:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('167', '669', '2019-08-07', '00:00 AM', '00:00 AM', '24', '45', '1', '9', '0', '', '2019-08-08', '2019-08-08 12:24:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('168', '670', '2019-08-07', '00:00 AM', '00:00 AM', '24', '34', '3', '9', '0', '', '2019-08-08', '2019-08-08 12:28:55');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('169', '671', '2019-08-07', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2019-08-08', '2019-08-08 12:30:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('170', '672', '2019-08-07', '00:00 AM', '00:00 AM', '4', '158', '2', '10', '0', '', '2019-08-08', '2019-08-08 12:31:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('171', '673', '2019-08-07', '00:00 AM', '00:00 AM', '29', '38', '3', '4', '0', '', '2019-08-08', '2019-08-08 12:32:10');


#
# TABLE STRUCTURE FOR: materials
#

DROP TABLE IF EXISTS `materials`;

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('1', '20 MM', '2018-07-24', '0', '2018-07-31 22:55:28');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('2', '10 MM', '2018-07-24', '0', '2018-07-31 22:55:19');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('3', '6 MM', '2018-07-24', '0', '2018-07-31 22:55:10');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('4', '3 shoot', '2018-07-24', '0', '2018-07-31 22:55:43');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('5', 'Dhoola', '2018-07-24', '0', '2018-07-31 22:56:47');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('6', 'M Send', '2018-07-28', '0', '2018-07-31 22:57:00');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('7', 'Reti', '2018-07-28', '0', '2018-07-31 22:57:11');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('8', '40 mm', '2018-09-18', '0', '2018-09-18 14:51:35');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('9', 'GSB', '2018-10-12', '0', '2018-10-12 17:07:39');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `email`, `password`, `role`, `created_date`, `name`, `mobile_no`, `description`, `entry_date`) VALUES ('1', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2018-07-22 14:41:58', 'Admin', '9098343935', '', '2018-07-20');


#
# TABLE STRUCTURE FOR: vehicles
#

DROP TABLE IF EXISTS `vehicles`;

CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vehicle_no` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=latin1;

INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('1', '1', '0324', '2018-08-03', '0', '2018-08-12 12:55:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('2', '2', '0324', '2018-08-03', '0', '2018-08-12 12:56:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('3', '3', '0324', '2018-08-03', '0', '2018-08-12 12:56:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('4', '4', '0324', '2018-08-03', '0', '2018-08-12 12:56:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('5', '5', '0324', '2018-08-03', '0', '2018-08-12 12:56:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('6', '6', '0324', '2018-08-03', '0', '2018-08-12 12:57:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('7', '7', '0324', '2018-08-03', '0', '2018-08-12 12:57:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('8', '8', '0324', '2018-08-03', '0', '2018-08-12 12:57:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('9', '9', '0324', '2018-08-03', '0', '2018-08-12 12:57:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('10', '10', '0324', '2018-08-03', '0', '2018-08-12 12:57:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('11', '11', '0324', '2018-08-03', '0', '2018-08-12 12:55:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('12', '12', '0324', '2018-08-03', '0', '2018-08-12 12:58:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('13', '13', '324', '2018-08-07', '0', '2018-08-07 18:10:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('14', '14', '0324', '2018-08-07', '0', '2018-08-07 18:15:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('15', '15', '0324', '2018-08-07', '0', '2018-08-07 18:19:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('16', '16', '0324', '2018-08-07', '0', '2018-08-07 18:38:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('17', '17', '0324', '2018-08-08', '0', '2018-08-08 10:33:35');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('18', '18', '0324', '2018-08-08', '0', '2018-08-08 10:40:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('19', '19', '0324', '2018-08-08', '0', '2018-08-08 16:07:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('20', '20', '0324', '2018-08-08', '0', '2018-08-08 16:09:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('21', '21', '3510', '2018-08-13', '0', '2018-08-13 11:51:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('22', '21', '0324', '2018-08-13', '0', '2018-08-13 11:51:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('23', '6', '6089', '2018-08-13', '0', '2018-08-13 12:01:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('24', '9', '0576', '2018-08-14', '0', '2018-08-14 11:11:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('25', '4', '9705', '2018-08-14', '0', '2018-08-14 11:13:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('26', '20', '9705', '2018-08-14', '0', '2018-08-14 11:16:46');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('27', '20', '3510', '2018-08-14', '0', '2018-08-14 11:17:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('28', '13', '0324', '2018-08-18', '0', '2018-08-18 10:48:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('29', '22', '0324', '2018-08-18', '0', '2018-08-18 11:32:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('30', '11', '4233', '2018-08-20', '0', '2018-08-20 14:34:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('31', '4', '0825', '2018-08-30', '0', '2018-08-30 16:19:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('32', '23', '1463', '2018-09-01', '0', '2018-09-01 11:37:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('33', '23', '8887', '2018-09-01', '0', '2018-09-01 11:39:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('34', '24', '0825', '2018-09-01', '0', '2018-09-01 11:45:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('35', '25', '4683', '2018-09-01', '0', '2018-09-01 11:47:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('36', '26', '1543', '2018-09-01', '0', '2018-09-01 11:49:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('37', '27', '2253', '2018-09-01', '0', '2018-09-01 11:52:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('38', '29', '3716', '2018-09-01', '0', '2018-09-01 11:56:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('39', '26', '2641', '2018-09-01', '0', '2018-09-01 12:00:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('40', '30', 'TRALI', '2018-09-01', '0', '2018-09-01 12:08:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('41', '23', '0221', '2018-09-01', '0', '2018-09-01 12:12:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('42', '31', '6089', '2018-09-01', '0', '2018-09-01 12:21:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('43', '32', '7238', '2018-09-01', '0', '2018-09-01 16:39:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('44', '32', '9705', '2018-09-01', '0', '2018-09-01 16:39:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('45', '24', '4233', '2018-09-01', '0', '2018-09-01 16:41:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('46', '25', '7707', '2018-09-01', '0', '2018-09-01 16:44:21');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('47', '33', '0207', '2018-09-01', '0', '2018-09-01 16:57:27');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('48', '34', '8669', '2018-09-02', '0', '2018-09-02 11:46:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('49', '23', '1251', '2018-09-02', '0', '2018-09-02 11:53:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('50', '26', '2103', '2018-09-02', '0', '2018-09-02 11:54:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('51', '26', '1752', '2018-09-02', '0', '2018-09-02 11:56:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('52', '35', '3510', '2018-09-02', '0', '2018-09-02 12:16:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('53', '35', '0324', '2018-09-02', '0', '2018-09-02 12:16:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('54', '26', '0809', '2018-09-02', '0', '2018-09-02 12:30:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('55', '36', '4311', '2018-09-03', '0', '2018-09-03 12:12:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('56', '37', '1783', '2018-09-03', '0', '2018-09-03 12:28:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('57', '38', '1385', '2018-09-03', '0', '2018-09-03 12:32:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('58', '39', 'trali', '2018-09-06', '0', '2018-09-06 14:56:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('59', '40', '3510', '2018-09-06', '0', '2018-09-06 15:06:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('60', '20', '6631', '2018-09-07', '0', '2018-09-07 14:47:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('61', '30', '9111', '2018-09-07', '0', '2018-09-07 15:42:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('62', '38', '6199', '2018-09-07', '0', '2018-09-07 15:45:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('63', '32', '0825', '2018-09-07', '0', '2018-09-07 15:53:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('64', '26', '0230', '2018-09-08', '0', '2018-09-08 15:50:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('65', '6', '576', '2018-09-10', '0', '2018-09-10 12:57:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('66', '11', '0576', '2018-09-10', '0', '2018-09-10 13:04:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('67', '11', '6089', '2018-09-10', '0', '2018-09-10 13:06:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('68', '15', '0576', '2018-09-10', '0', '2018-09-10 13:07:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('69', '15', '6089', '2018-09-10', '0', '2018-09-10 13:08:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('70', '17', '0825', '2018-09-11', '0', '2018-09-11 12:16:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('71', '30', '5106', '2018-09-11', '0', '2018-09-11 12:20:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('72', '32', '3716', '2018-09-11', '0', '2018-09-11 12:25:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('73', '30', '0834', '2018-09-11', '0', '2018-09-11 12:39:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('74', '41', '0324', '2018-09-11', '0', '2018-09-11 12:42:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('75', '11', '1783', '2018-09-13', '0', '2018-09-13 14:46:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('76', '42', '0324', '2018-09-15', '0', '2018-09-15 15:25:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('77', '11', '0221', '2018-09-15', '0', '2018-09-15 15:39:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('78', '26', '2182', '2018-09-15', '0', '2018-09-15 15:42:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('79', '40', '0576', '2018-09-18', '0', '2018-09-18 10:38:32');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('80', '4', '1752', '2018-09-18', '0', '2018-09-18 11:11:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('81', '43', '2804', '2018-09-18', '0', '2018-09-18 14:47:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('82', '11', '0825', '2018-09-18', '0', '2018-09-18 14:54:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('83', '43', '4612', '2018-09-18', '0', '2018-09-18 15:02:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('84', '3', '0221', '2018-09-20', '0', '2018-09-20 13:44:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('85', '44', '6199', '2018-09-21', '0', '2018-09-21 09:38:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('86', '24', '0324', '2018-09-21', '0', '2018-09-21 16:19:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('87', '16', '6089', '2018-09-24', '0', '2018-09-24 15:36:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('88', '21', '0576', '2018-09-24', '0', '2018-09-24 15:43:18');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('89', '3', '6089', '2018-09-25', '0', '2018-09-25 15:05:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('90', '35', '0576', '2018-09-25', '0', '2018-09-25 15:13:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('91', '19', '6089', '2018-09-26', '0', '2018-09-26 14:46:22');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('92', '2', '7238', '2018-09-26', '0', '2018-09-26 14:58:09');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('93', '11', '7238', '2018-09-27', '0', '2018-09-27 15:50:24');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('94', '45', '2704', '2018-09-29', '0', '2018-09-29 15:53:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('95', '3', '7238', '2018-09-30', '0', '2018-09-30 15:42:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('96', '46', '3510', '2018-09-30', '0', '2018-09-30 15:47:24');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('97', '46', '0324', '2018-09-30', '0', '2018-09-30 15:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('98', '47', '0324', '2018-10-01', '0', '2018-10-01 15:30:29');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('99', '48', '3510', '2018-10-01', '0', '2018-10-01 15:44:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('100', '4', '0221', '2018-10-02', '0', '2018-10-02 15:25:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('101', '13', '3714', '2018-10-03', '0', '2018-10-03 15:05:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('102', '11', '3716', '2018-10-04', '0', '2018-10-04 15:48:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('103', '32', '8589', '2018-10-06', '0', '2018-10-06 15:08:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('104', '49', '0948', '2018-10-07', '0', '2018-10-07 15:14:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('105', '50', '2454', '2018-10-07', '0', '2018-10-07 15:41:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('106', '34', '0669', '2018-10-07', '0', '2018-10-07 15:51:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('107', '3', '1785', '2018-10-10', '0', '2018-10-10 16:06:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('108', '29', '0324', '2018-10-11', '0', '2018-10-11 16:21:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('109', '45', '3580', '2018-10-11', '0', '2018-10-11 16:32:37');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('110', '51', '2454', '2018-10-12', '0', '2018-10-12 09:49:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('111', '13', '0825', '2018-10-12', '0', '2018-10-12 17:04:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('112', '17', '3716', '2018-10-13', '0', '2018-10-13 15:31:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('113', '6', '7767', '2018-10-24', '0', '2018-10-24 13:03:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('114', '11', '7767', '2018-10-24', '0', '2018-10-24 14:07:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('115', '4', '7767', '2018-10-24', '0', '2018-10-24 16:29:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('116', '24', '6631', '2018-10-25', '0', '2018-10-25 11:32:59');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('117', '30', '0324', '2018-10-27', '0', '2018-10-27 10:18:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('118', '52', '0477', '2018-10-29', '0', '2018-10-29 12:17:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('119', '53', '0948', '2018-10-29', '0', '2018-10-29 12:29:22');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('120', '52', '0277', '2018-10-29', '0', '2018-10-29 12:38:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('121', '53', '2573', '2018-10-29', '0', '2018-10-29 17:04:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('122', '7', '4233', '2018-10-31', '0', '2018-10-31 11:13:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('123', '49', '2573', '2018-11-01', '0', '2018-11-01 11:34:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('124', '49', '8911', '2018-11-01', '0', '2018-11-01 11:39:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('125', '53', '8911', '2018-11-01', '0', '2018-11-01 15:40:11');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('126', '31', '0324', '2018-11-04', '0', '2018-11-04 16:58:32');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('127', '42', '0825', '2018-11-04', '0', '2018-11-04 17:00:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('128', '38', '0674', '2018-11-10', '0', '2018-11-10 15:12:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('129', '53', '0911', '2018-11-13', '0', '2018-11-13 15:23:43');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('130', '43', '5111', '2018-11-13', '0', '2018-11-13 15:40:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('131', '38', '0324', '2018-11-13', '0', '2018-11-13 15:43:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('132', '30', '8887', '2018-11-13', '0', '2018-11-13 15:45:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('133', '9', '3510', '2018-11-13', '0', '2018-11-13 15:50:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('134', '46', '0576', '2018-11-14', '0', '2018-11-14 15:48:18');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('135', '48', '0324', '2018-11-14', '0', '2018-11-14 16:02:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('136', '55', '0324', '2018-11-14', '0', '2018-11-14 16:14:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('137', '11', '8887', '2018-11-15', '0', '2018-11-15 15:14:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('138', '56', '3510', '2018-11-18', '0', '2018-11-18 15:49:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('139', '42', '7238', '2018-11-18', '0', '2018-11-18 16:08:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('140', '57', '9999', '2018-11-20', '0', '2018-11-20 14:53:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('141', '58', '8887', '2018-11-22', '0', '2018-11-22 16:34:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('142', '31', '3510', '2018-11-29', '0', '2018-11-29 14:52:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('143', '41', '4233', '2018-12-01', '0', '2018-12-01 09:53:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('144', '46', '4200', '2018-12-04', '0', '2018-12-04 13:58:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('145', '59', '0324', '2018-12-06', '0', '2018-12-06 12:21:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('146', '12', '4200', '2018-12-06', '0', '2018-12-06 15:52:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('147', '60', '0324', '2018-12-10', '0', '2018-12-10 15:43:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('148', '41', '4200', '2018-12-11', '0', '2018-12-11 12:47:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('149', '2', '4200', '2018-12-13', '0', '2018-12-13 15:22:55');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('150', '61', '0324', '2018-12-15', '0', '2018-12-15 14:55:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('151', '10', '4200', '2018-12-15', '0', '2018-12-15 15:09:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('152', '62', '0324', '2018-12-17', '0', '2018-12-17 16:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('153', '63', '0324', '2018-12-17', '0', '2018-12-17 16:52:11');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('154', '63', '4200', '2018-12-17', '0', '2018-12-17 16:52:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('155', '13', '4200', '2018-12-19', '0', '2018-12-19 13:36:54');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('156', '24', '3716', '2018-12-19', '0', '2018-12-19 17:05:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('157', '62', '4200', '2018-12-21', '0', '2018-12-21 09:47:41');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('158', '4', '4200', '2018-12-21', '0', '2018-12-21 15:16:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('159', '14', '4200', '2018-12-21', '0', '2018-12-21 17:26:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('160', '6', '4200', '2018-12-22', '0', '2018-12-22 16:15:43');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('161', '11', '4200', '2018-12-22', '0', '2018-12-22 16:18:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('162', '64', '4200', '2018-12-22', '0', '2018-12-22 16:34:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('163', '9', '4200', '2018-12-23', '0', '2018-12-23 12:09:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('164', '65', '4200', '2018-12-23', '0', '2018-12-23 15:01:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('165', '30', '4200', '2018-12-25', '0', '2018-12-25 17:59:16');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('166', '26', '4841', '2018-12-25', '0', '2018-12-25 18:08:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('167', '52', '0111', '2018-12-25', '0', '2018-12-25 18:17:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('168', '24', '1783', '2018-12-27', '0', '2018-12-27 11:42:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('169', '43', '4613', '2018-12-27', '0', '2018-12-27 11:49:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('170', '66', '4388', '2018-12-28', '0', '2018-12-28 13:30:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('171', '67', '0324', '2018-12-28', '0', '2018-12-28 16:55:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('172', '68', '4200', '2018-12-29', '0', '2018-12-29 15:23:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('173', '70', '0324', '2018-12-30', '0', '2018-12-30 16:40:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('174', '46', '7767', '2018-12-31', '0', '2018-12-31 15:59:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('175', '23', 'maijik', '2019-01-02', '0', '2019-01-02 11:17:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('176', '19', '4200', '2019-01-02', '0', '2019-01-02 11:20:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('177', '71', '0324', '2019-01-02', '0', '2019-01-02 15:34:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('178', '72', '4200', '2019-01-02', '0', '2019-01-02 15:41:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('179', '73', '0324', '2019-01-04', '0', '2019-01-04 10:10:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('180', '71', '4200', '2019-01-08', '0', '2019-01-08 14:59:43');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('181', '47', '7767', '2019-01-11', '0', '2019-01-11 14:28:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('182', '59', '7767', '2019-01-11', '0', '2019-01-11 16:28:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('183', '74', '0324', '2019-01-12', '0', '2019-01-12 17:02:58');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('184', '75', '0324', '2019-01-12', '0', '2019-01-12 17:10:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('185', '15', '4200', '2019-01-15', '0', '2019-01-15 11:17:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('186', '2', '6089', '2019-01-15', '0', '2019-01-15 11:23:54');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('187', '6', '8887', '2019-01-16', '0', '2019-01-16 16:30:17');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('188', '21', '4200', '2019-01-21', '0', '2019-01-21 12:22:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('189', '43', '2934', '2019-01-28', '0', '2019-01-28 11:46:29');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('190', '8', '4200', '2019-01-28', '0', '2019-01-28 16:56:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('191', '19', '8887', '2019-01-30', '0', '2019-01-30 11:43:19');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('192', '43', '2805', '2019-01-31', '0', '2019-01-31 15:22:04');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('193', '76', '0324', '2019-02-02', '0', '2019-02-02 16:11:59');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('194', '76', '4200', '2019-02-02', '0', '2019-02-02 16:12:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('195', '23', '0324', '2019-02-06', '0', '2019-02-06 11:55:20');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('196', '41', '0948', '2019-02-08', '0', '2019-02-08 10:14:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('197', '10', '0188', '2019-02-08', '0', '2019-02-08 10:18:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('198', '77', '0324', '2019-02-09', '0', '2019-02-09 16:19:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('199', '77', '6089', '2019-02-09', '0', '2019-02-09 16:20:02');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('200', '77', '0188', '2019-02-09', '0', '2019-02-09 16:21:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('201', '16', '4200', '2019-02-16', '0', '2019-02-16 12:36:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('202', '23', '3842', '2019-02-20', '0', '2019-02-20 13:01:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('203', '53', '2253', '2019-02-26', '0', '2019-02-26 12:53:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('204', '7', '8887', '2019-03-08', '0', '2019-03-08 10:12:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('205', '78', '0324', '2019-03-09', '0', '2019-03-09 17:32:30');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('206', '13', '6089', '2019-03-12', '0', '2019-03-12 17:02:12');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('207', '47', '4200', '2019-03-14', '0', '2019-03-14 11:21:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('208', '23', '7238', '2019-03-16', '0', '2019-03-16 15:50:10');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('209', '23', '1783', '2019-03-16', '0', '2019-03-16 15:51:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('210', '23', '4200', '2019-03-19', '0', '2019-03-19 12:32:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('211', '79', '4200', '2019-03-24', '0', '2019-03-24 11:13:27');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('212', '5', '4233', '2019-03-27', '0', '2019-03-27 12:32:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('213', '46', '1783', '2019-03-28', '0', '2019-03-28 17:23:11');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('214', '80', '0324', '2019-04-12', '0', '2019-04-12 16:49:08');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('215', '31', '4200', '2019-04-16', '0', '2019-04-16 17:28:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('216', '5', '4200', '2019-04-19', '0', '2019-04-19 17:28:07');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('217', '32', '4233', '2019-04-19', '0', '2019-04-19 17:36:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('218', '20', '1783', '2019-04-20', '0', '2019-04-20 14:05:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('219', '22', '4200', '2019-04-20', '0', '2019-04-20 14:16:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('220', '30', '1783', '2019-04-27', '0', '2019-04-27 14:41:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('221', '6', '0825', '2019-04-27', '0', '2019-04-27 14:46:29');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('222', '2', '0825', '2019-04-27', '0', '2019-04-27 14:50:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('223', '2', '4233', '2019-04-27', '0', '2019-04-27 16:26:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('224', '81', '0324', '2019-06-07', '0', '2019-06-07 18:09:31');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('225', '81', '4200', '2019-06-07', '0', '2019-06-07 18:09:50');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('226', '32', '1783', '2019-06-08', '0', '2019-06-08 11:58:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('227', '32', '4200', '2019-06-08', '0', '2019-06-08 16:44:13');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('228', '32', 'trali', '2019-06-08', '0', '2019-06-08 16:46:27');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('229', '81', '3510', '2019-06-11', '0', '2019-06-11 15:58:27');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('230', '46', '0825', '2019-06-11', '0', '2019-06-11 16:03:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('231', '10', '4233', '2019-06-11', '0', '2019-06-11 18:01:01');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('232', '53', '0953', '2019-06-24', '0', '2019-06-24 16:58:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('233', '41', '6089', '2019-07-09', '0', '2019-07-09 12:36:28');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('234', '20', 'TRALI', '2019-07-30', '0', '2019-07-30 11:49:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('235', '32', '6631', '2019-08-08', '0', '2019-08-08 12:06:13');


