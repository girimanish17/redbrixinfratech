#
# TABLE STRUCTURE FOR: bills
#

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `bill_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `due` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `tax_amount` int(11) NOT NULL,
  `diposit_amount` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('1', 'sampat', '8602442648', 'indore m.p', '2018-08-03', '0', '2018-08-02 21:39:12');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('2', 'maze buildcon', '1111111111', 'indore m.p', '2018-08-03', '0', '2018-08-02 21:56:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('3', 'sayta', '1011111111', 'indore m.p', '2018-08-03', '0', '2018-08-02 21:58:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('4', 'sardar ji', '1234567011', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:00:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('5', 'gangotri ', '1200311111', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:01:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('6', 'gaurav jain', '2222000002', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:02:21');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('7', 'desai ji', '3333333333', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:03:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('8', 'hebal som', '3333333331', 'khndwa road indore m.p', '2018-08-03', '0', '2018-08-02 22:11:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('9', 'singhl sahb', '1110000007', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:12:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('10', 'mukesh prajapat', '9827250327', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:40:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('11', 'makhija ji', '5555555555', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:45:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('12', 'natraj tiles', '6666666666', 'indore m.p', '2018-08-03', '0', '2018-08-03 01:56:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('13', 'badwani ji', '1000001112', 'khndwa road indore', '2018-08-07', '0', '2018-08-07 05:40:27');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('14', 'ultra tech', '4444440909', 'indore m.p', '2018-08-07', '0', '2018-08-07 05:45:19');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('15', 'kukreja ji', '7070708888', 'indore m.p', '2018-08-07', '0', '2018-08-07 05:49:17');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('16', 'jk buildcon', '1010101010', 'indore m.p', '2018-08-07', '0', '2018-08-07 06:07:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('17', 'parsawnath ji', '8989898980', 'indore m.p', '2018-08-08', '0', '2018-08-07 22:03:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('18', 'jai baba', '7030500005', 'indore m.p', '2018-08-08', '0', '2018-08-07 22:09:53');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('19', 'ML AGARWAL SCHOOL', '6565656565', 'INDORE MP', '2018-08-08', '0', '2018-08-08 03:36:40');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('20', 'kapil pariya', '5050505060', 'indore mp', '2018-08-08', '0', '2018-08-08 03:39:39');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('21', 'capital', '7676767687', 'brg indore', '2018-08-13', '0', '2018-08-12 23:20:57');


#
# TABLE STRUCTURE FOR: dues
#

DROP TABLE IF EXISTS `dues`;

CREATE TABLE `dues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('1', '1', '0', '2018-08-02 21:45:32');


#
# TABLE STRUCTURE FOR: gate_pass
#

DROP TABLE IF EXISTS `gate_pass`;

CREATE TABLE `gate_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` varchar(250) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `client_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=latin1;

INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('1', '1', '2018-07-31', '05:00 AM', '00:00 AM', '1', '1', '1', '7', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('2', '2', '2018-07-30', '06:00 AM', '00:00 AM', '1', '1', '2', '5', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('3', '3', '2018-07-29', '03:00 AM', '00:00 AM', '1', '1', '3', '8', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('4', '4', '2018-07-31', '02:00 AM', '00:00 AM', '1', '1', '7', '7', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('5', '968', '2018-08-01', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:31:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('6', '964', '2018-08-01', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:32:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('7', '977', '2018-08-01', '00:00 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-03', '2018-08-03 01:32:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('8', '989', '2018-08-01', '00:00 AM', '00:00 AM', '4', '4', '3', '22', '0', '', '2018-08-03', '2018-08-03 01:33:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('9', '1000', '2018-08-01', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2018-08-03', '2018-08-03 02:16:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('10', '10', '2018-08-01', '00:00 AM', '00:00 AM', '5', '5', '7', '22', '0', '', '2018-08-03', '2018-08-03 01:34:10');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('11', '11', '2018-08-01', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:34:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('12', '12', '2018-08-01', '00:00 AM', '00:00 AM', '7', '7', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:35:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('13', '13', '2018-08-01', '00:00 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-03', '2018-08-03 01:35:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('14', '14', '2018-08-01', '00:00 AM', '00:00 AM', '8', '8', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:36:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('15', '15', '2018-08-01', '00:00 AM', '00:00 AM', '9', '9', '5', '22', '0', '', '2018-08-03', '2018-08-03 01:36:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('16', '16', '2018-08-01', '00:00 AM', '00:00 AM', '5', '5', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:37:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('17', '22', '2018-08-02', '00:00 AM', '00:00 AM', '10', '10', '3', '22', '0', '', '2018-08-03', '2018-08-03 01:38:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('18', '34', '2018-08-02', '00:00 AM', '00:00 AM', '4', '4', '2', '22', '0', '', '2018-08-03', '2018-08-03 01:39:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('19', '38', '2018-08-02', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:40:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('20', '42', '2018-08-02', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:41:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('21', '45', '2018-08-02', '00:00 AM', '00:00 AM', '5', '5', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:42:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('22', '49', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '7', '22', '0', '', '2018-08-03', '2018-08-03 01:45:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('23', '50', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:46:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('24', '51', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:47:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('25', '52', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '3', '22', '0', '', '2018-08-03', '2018-08-03 01:48:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('26', '53', '2018-08-02', '00:00 AM', '00:00 AM', '12', '12', '5', '22', '0', '', '2018-08-03', '2018-08-03 02:04:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('27', '60', '2018-08-03', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2018-08-03', '2018-08-03 02:06:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('28', '59', '2018-08-03', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 02:07:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('29', '82', '2018-08-03', '17:05 PM', '00:00 AM', '13', '13', '1', '22', '0', '', '2018-08-07', '2018-08-07 05:41:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('30', '87', '2018-08-03', '20:50 PM', '00:00 AM', '14', '14', '7', '22', '0', '', '2018-08-07', '2018-08-07 05:46:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('31', '88', '2018-08-03', '23:20 PM', '00:00 AM', '6', '6', '5', '22', '0', '', '2018-08-07', '2018-08-07 05:48:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('32', '89', '2018-08-03', '00:55 AM', '00:00 AM', '15', '15', '3', '22', '0', '', '2018-08-07', '2018-08-07 05:50:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('33', '90', '2018-08-03', '03:20 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-07', '2018-08-07 05:52:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('34', '91', '2018-08-03', '05:20 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-07', '2018-08-07 05:54:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('35', '92', '2018-08-03', '07:05 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-07', '2018-08-07 05:56:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('36', '93', '2018-08-04', '08:45 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-07', '2018-08-07 05:58:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('37', '104', '2018-08-04', '11:10 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:03:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('38', '109', '2018-08-04', '12:15 PM', '00:00 AM', '4', '4', '5', '22', '0', '', '2018-08-07', '2018-08-07 06:04:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('39', '111', '2018-08-04', '02:10 AM', '00:00 AM', '16', '16', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:09:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('40', '116', '2018-08-04', '15:30 PM', '00:00 AM', '13', '13', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:10:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('41', '120', '2018-08-04', '17:15 PM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:13:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('42', '130', '2018-08-04', '20:20 PM', '00:00 AM', '13', '13', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:17:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('43', '131', '2018-08-04', '22:30 PM', '00:00 AM', '13', '13', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:18:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('44', '133', '2018-08-04', '00:10 AM', '00:00 AM', '16', '16', '7', '22', '0', '', '2018-08-07', '2018-08-07 06:22:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('45', '136', '2018-08-04', '02:25 AM', '00:00 AM', '11', '11', '7', '22', '0', '', '2018-08-07', '2018-08-07 06:25:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('46', '137', '2018-08-04', '04:50 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:28:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('47', '138', '2018-08-04', '06:55 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:31:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('48', '128', '2018-08-04', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-07', '2018-08-07 06:35:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('49', '144', '2018-08-05', '10:00 AM', '00:00 AM', '16', '16', '1', '16', '0', '', '2018-08-08', '2018-08-07 21:46:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('50', '155', '2018-08-05', '13:00 PM', '00:00 AM', '4', '4', '5', '22', '0', '', '2018-08-08', '2018-08-07 21:47:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('51', '160', '2018-08-05', '14:45 PM', '00:00 AM', '16', '16', '7', '22', '0', '', '2018-08-08', '2018-08-07 21:49:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('52', '163', '2018-08-05', '17:30 PM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-08', '2018-08-07 21:51:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('53', '166', '2018-08-05', '19:00 PM', '00:00 AM', '9', '9', '3', '22', '0', '', '2018-08-08', '2018-08-07 21:52:18');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('54', '167', '2018-08-05', '20:00 PM', '00:00 AM', '11', '11', '3', '22', '0', '', '2018-08-08', '2018-08-07 21:53:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('55', '168', '2018-08-05', '22:30 PM', '00:00 AM', '13', '13', '1', '22', '0', '', '2018-08-08', '2018-08-07 21:55:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('56', '169', '2018-08-05', '01:40 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-08', '2018-08-07 21:57:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('57', '170', '2018-08-05', '03:35 AM', '00:00 AM', '10', '10', '3', '22', '0', '', '2018-08-08', '2018-08-07 21:58:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('58', '175', '2018-08-06', '10:00 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-08', '2018-08-07 22:00:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('59', '180', '2018-08-06', '11:50 AM', '00:00 AM', '3', '3', '1', '22', '0', '', '2018-08-08', '2018-08-07 22:01:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('60', '184', '2018-08-06', '13:20 PM', '00:00 AM', '17', '17', '3', '22', '0', '', '2018-08-08', '2018-08-07 22:04:36');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('61', '193', '2018-08-06', '16:00 PM', '00:00 AM', '17', '17', '3', '22', '0', '', '2018-08-08', '2018-08-07 22:06:05');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('62', '198', '2018-08-06', '18:10 PM', '00:00 AM', '17', '17', '3', '22', '0', '', '2018-08-08', '2018-08-07 22:07:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('63', '200', '2018-08-06', '20:30 PM', '00:00 AM', '18', '18', '2', '22', '0', '', '2018-08-08', '2018-08-07 22:11:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('64', '203', '2018-08-06', '23:05 PM', '00:00 AM', '18', '18', '3', '22', '0', '', '2018-08-08', '2018-08-07 22:13:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('65', '206', '2018-08-06', '00:00 AM', '00:00 AM', '11', '11', '3', '22', '0', '', '2018-08-08', '2018-08-07 22:15:09');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('66', '209', '2018-08-06', '03:10 AM', '00:00 AM', '11', '11', '7', '22', '0', '', '2018-08-08', '2018-08-07 22:16:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('67', '210', '2018-08-06', '05:10 AM', '00:00 AM', '4', '4', '5', '22', '0', '', '2018-08-08', '2018-08-07 22:17:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('68', '211', '2018-08-07', '08:30 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2018-08-08', '2018-08-07 22:20:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('69', '223', '2018-08-07', '11:05 AM', '00:00 AM', '19', '19', '1', '22', '0', '', '2018-08-08', '2018-08-08 03:37:59');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('70', '227', '2018-08-07', '12:20 PM', '00:00 AM', '20', '20', '1', '22', '0', '', '2018-08-08', '2018-08-08 03:41:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('71', '227', '2018-08-07', '12:20 PM', '00:00 AM', '20', '20', '1', '22', '0', '', '2018-08-08', '2018-08-08 03:41:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('72', '232', '2018-08-07', '13:40 PM', '00:00 AM', '6', '6', '3', '22', '0', '', '2018-08-08', '2018-08-08 03:42:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('73', '241', '2018-08-07', '16:40 PM', '00:00 AM', '14', '14', '7', '22', '0', '', '2018-08-08', '2018-08-08 03:46:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('74', '247', '2018-08-07', '18:30 PM', '00:00 AM', '3', '3', '3', '22', '0', '', '2018-08-08', '2018-08-08 03:51:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('75', '249', '2018-08-07', '19:30 PM', '00:00 AM', '3', '3', '7', '22', '0', '', '2018-08-08', '2018-08-08 03:53:13');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('76', '250', '2018-08-07', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-08', '2018-08-08 03:56:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('77', '251', '2018-08-07', '01:40 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-08', '2018-08-08 03:57:44');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('78', '252', '2018-08-07', '04:35 AM', '00:00 AM', '11', '11', '7', '22', '0', '', '2018-08-08', '2018-08-08 03:58:47');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('79', '253', '2018-08-07', '06:10 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-08', '2018-08-08 03:59:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('80', '254', '2018-08-08', '08:50 AM', '00:00 AM', '20', '20', '1', '22', '0', '', '2018-08-09', '2018-08-08 22:28:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('81', '263', '2018-08-08', '10:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2018-08-09', '2018-08-08 22:30:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('82', '271', '2018-08-08', '12:30 PM', '00:00 AM', '9', '9', '3', '22', '0', '', '2018-08-09', '2018-08-08 22:31:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('83', '275', '2018-08-08', '13:20 PM', '00:00 AM', '4', '4', '2', '22', '0', '', '2018-08-09', '2018-08-08 22:32:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('84', '283', '2018-08-08', '16:15 PM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-09', '2018-08-08 22:35:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('85', '290', '2018-08-08', '05:40 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-09', '2018-08-08 22:37:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('86', '292', '2018-08-08', '19:15 PM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-09', '2018-08-08 22:38:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('87', '295', '2018-08-08', '21:30 PM', '00:00 AM', '11', '11', '3', '22', '0', '', '2018-08-09', '2018-08-08 22:40:00');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('88', '297', '2018-08-08', '00:20 AM', '00:00 AM', '15', '15', '3', '22', '0', '', '2018-08-09', '2018-08-08 22:41:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('89', '298', '2018-08-08', '07:40 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-09', '2018-08-08 22:43:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('90', '306', '2018-08-09', '10:20 AM', '00:00 AM', '16', '16', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:36:30');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('91', '314', '2018-08-09', '12:20 PM', '00:00 AM', '4', '4', '3', '22', '0', '', '2018-08-12', '2018-08-11 22:37:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('92', '321', '2018-08-09', '14:10 PM', '00:00 AM', '16', '16', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:39:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('93', '328', '2018-08-09', '15:35 PM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:41:16');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('94', '334', '2018-08-09', '17:10 PM', '00:00 AM', '16', '16', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:42:43');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('95', '336', '2018-08-09', '18:30 PM', '00:00 AM', '14', '14', '7', '22', '0', '', '2018-08-12', '2018-08-11 22:44:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('96', '338', '2018-08-09', '21:45 PM', '00:00 AM', '3', '3', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:47:02');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('97', '339', '2018-08-09', '23:25 PM', '00:00 AM', '16', '16', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:48:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('98', '340', '2018-08-09', '01:10 AM', '00:00 AM', '11', '11', '7', '22', '0', '', '2018-08-12', '2018-08-11 22:49:35');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('99', '341', '2018-08-09', '04:00 AM', '00:00 AM', '11', '11', '3', '22', '0', '', '2018-08-12', '2018-08-11 22:50:50');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('100', '342', '2018-08-09', '06:30 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-12', '2018-08-11 22:51:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('101', '352', '2018-08-10', '10:45 AM', '00:00 AM', '4', '4', '5', '22', '0', '', '2018-08-12', '2018-08-12 00:18:34');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('102', '359', '2018-08-10', '12:05 PM', '00:00 AM', '16', '16', '1', '22', '0', '', '2018-08-12', '2018-08-12 00:19:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('103', '365', '2018-08-10', '14:30 PM', '00:00 AM', '4', '4', '2', '22', '0', '', '2018-08-12', '2018-08-13 22:33:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('104', '375', '2018-08-10', '16:05 PM', '00:00 AM', '3', '3', '3', '22', '0', '', '2018-08-12', '2018-08-12 00:22:08');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('105', '383', '2018-08-10', '18:45 PM', '00:00 AM', '9', '9', '5', '22', '0', '', '2018-08-12', '2018-08-12 00:24:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('106', '391', '2018-08-12', '10:35 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:22:49');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('107', '396', '2018-08-12', '11:50 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:23:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('108', '400', '2018-08-12', '12:15 PM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:24:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('109', '406', '2018-08-12', '14:30 PM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-12 23:26:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('110', '409', '2018-08-12', '15:00 PM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-12 23:27:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('111', '410', '2018-08-12', '15:30 PM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-12 23:28:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('112', '414', '2018-08-12', '16:50 PM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:29:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('113', '416', '2018-08-12', '17:35 PM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-12 23:30:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('114', '420', '2018-08-12', '19:55 PM', '00:00 AM', '6', '23', '3', '10', '0', '', '2018-08-13', '2018-08-12 23:34:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('115', '421', '2018-08-12', '21:20 PM', '00:00 AM', '6', '23', '5', '10', '0', '', '2018-08-13', '2018-08-12 23:35:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('116', '421', '2018-08-12', '23:00 PM', '00:00 AM', '6', '23', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:39:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('117', '423', '2018-08-12', '01:00 AM', '00:00 AM', '6', '23', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:40:12');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('118', '76', '2018-08-03', '00:00 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:58:25');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('119', '79', '2018-08-03', '00:00 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-12 23:59:58');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('120', '83', '2018-08-03', '00:00 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-13 00:00:26');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('121', '84', '2018-08-03', '00:00 AM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-13 00:02:28');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('122', '181', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-13 00:04:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('123', '182', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-13 00:06:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('124', '187', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-13 00:06:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('125', '194', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '1', '10', '0', '', '2018-08-13', '2018-08-13 00:07:27');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('126', '195', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-13 00:08:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('127', '195', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-13 00:10:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('128', '197', '2018-08-06', '00:00 AM', '00:00 AM', '21', '21', '2', '10', '0', '', '2018-08-13', '2018-08-13 00:11:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('129', '452', '2018-08-13', '21:30 PM', '00:00 AM', '6', '6', '5', '22', '0', '', '2018-08-14', '2018-08-13 22:37:53');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('130', '453', '2018-08-13', '11:10 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-14', '2018-08-13 22:38:42');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('131', '454', '2018-08-13', '01:40 AM', '00:00 AM', '5', '5', '7', '22', '0', '', '2018-08-14', '2018-08-13 22:40:23');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('132', '451', '2018-08-13', '19:10 PM', '00:00 AM', '9', '24', '3', '10', '0', '', '2018-08-14', '2018-08-13 22:42:06');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('133', '434', '2018-08-13', '11:00 AM', '00:00 AM', '4', '25', '1', '10', '0', '', '2018-08-14', '2018-08-13 22:44:46');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('134', '445', '2018-08-13', '15:50 PM', '00:00 AM', '4', '25', '3', '10', '0', '', '2018-08-14', '2018-08-13 22:46:14');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('135', '71', '2018-08-01', '00:00 AM', '00:00 AM', '20', '27', '1', '10', '0', '', '2018-08-14', '2018-08-13 22:51:11');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('136', '73', '2018-08-01', '00:00 AM', '00:00 AM', '20', '27', '1', '10', '0', '', '2018-08-14', '2018-08-13 22:51:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('137', '238', '2018-08-01', '15:30 PM', '00:00 AM', '20', '27', '1', '10', '0', '', '2018-08-14', '2018-08-13 22:53:54');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('138', '436', '2018-08-13', '12:10 PM', '00:00 AM', '20', '27', '1', '10', '0', '', '2018-08-14', '2018-08-13 22:57:19');


#
# TABLE STRUCTURE FOR: materials
#

DROP TABLE IF EXISTS `materials`;

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('1', '20 MM', '2018-07-24', '0', '2018-07-31 10:25:28');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('2', '10 MM', '2018-07-24', '0', '2018-07-31 10:25:19');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('3', '6 MM', '2018-07-24', '0', '2018-07-31 10:25:10');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('4', '3 shoot', '2018-07-24', '0', '2018-07-31 10:25:43');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('5', 'Dhoola', '2018-07-24', '0', '2018-07-31 10:26:47');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('6', 'M Send', '2018-07-28', '0', '2018-07-31 10:27:00');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('7', 'Reti', '2018-07-28', '0', '2018-07-31 10:27:11');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `email`, `password`, `role`, `created_date`, `name`, `mobile_no`, `description`, `entry_date`) VALUES ('1', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2018-07-22 02:11:58', 'Admin', '9098343935', '', '2018-07-20');


#
# TABLE STRUCTURE FOR: vehicles
#

DROP TABLE IF EXISTS `vehicles`;

CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vehicle_no` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('1', '1', '0324', '2018-08-03', '0', '2018-08-12 00:25:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('2', '2', '0324', '2018-08-03', '0', '2018-08-12 00:26:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('3', '3', '0324', '2018-08-03', '0', '2018-08-12 00:26:26');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('4', '4', '0324', '2018-08-03', '0', '2018-08-12 00:26:36');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('5', '5', '0324', '2018-08-03', '0', '2018-08-12 00:26:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('6', '6', '0324', '2018-08-03', '0', '2018-08-12 00:27:03');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('7', '7', '0324', '2018-08-03', '0', '2018-08-12 00:27:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('8', '8', '0324', '2018-08-03', '0', '2018-08-12 00:27:25');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('9', '9', '0324', '2018-08-03', '0', '2018-08-12 00:27:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('10', '10', '0324', '2018-08-03', '0', '2018-08-12 00:27:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('11', '11', '0324', '2018-08-03', '0', '2018-08-12 00:25:42');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('12', '12', '0324', '2018-08-03', '0', '2018-08-12 00:28:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('13', '13', '324', '2018-08-07', '0', '2018-08-07 05:40:52');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('14', '14', '0324', '2018-08-07', '0', '2018-08-07 05:45:40');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('15', '15', '0324', '2018-08-07', '0', '2018-08-07 05:49:38');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('16', '16', '0324', '2018-08-07', '0', '2018-08-07 06:08:47');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('17', '17', '0324', '2018-08-08', '0', '2018-08-07 22:03:35');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('18', '18', '0324', '2018-08-08', '0', '2018-08-07 22:10:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('19', '19', '0324', '2018-08-08', '0', '2018-08-08 03:37:06');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('20', '20', '0324', '2018-08-08', '0', '2018-08-08 03:39:56');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('21', '21', '3510', '2018-08-13', '0', '2018-08-12 23:21:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('22', '21', '0324', '2018-08-13', '0', '2018-08-12 23:21:51');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('23', '6', '6089', '2018-08-13', '0', '2018-08-12 23:31:48');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('24', '9', '0576', '2018-08-14', '0', '2018-08-13 22:41:05');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('25', '4', '9705', '2018-08-14', '0', '2018-08-13 22:43:53');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('26', '20', '9705', '2018-08-14', '0', '2018-08-13 22:46:46');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('27', '20', '3510', '2018-08-14', '0', '2018-08-13 22:47:02');


