#
# TABLE STRUCTURE FOR: bills
#

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `bill_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `due` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `tax_amount` int(11) NOT NULL,
  `diposit_amount` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('1', 'sampat', '8602442648', 'indore m.p', '2018-08-03', '0', '2018-08-02 21:39:12');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('2', 'maze buildcon', '1111111111', 'indore m.p', '2018-08-03', '0', '2018-08-02 21:56:16');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('3', 'sayta', '1011111111', 'indore m.p', '2018-08-03', '0', '2018-08-02 21:58:51');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('4', 'sardar ji', '1234567011', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:00:13');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('5', 'gangotri ', '1200311111', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:01:18');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('6', 'gaurav jain', '2222000002', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:02:21');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('7', 'desai ji', '3333333333', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:03:14');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('8', 'hebal som', '3333333331', 'khndwa road indore m.p', '2018-08-03', '0', '2018-08-02 22:11:04');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('9', 'singhl sahb', '1110000007', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:12:30');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('10', 'mukesh prajapat', '9827250327', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:40:11');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('11', 'makhija ji', '5555555555', 'indore m.p', '2018-08-03', '0', '2018-08-02 22:45:28');
INSERT INTO `clients` (`client_id`, `client_name`, `mobile_no`, `address`, `entry_date`, `status`, `date_time`) VALUES ('12', 'natraj tiles', '6666666666', 'indore m.p', '2018-08-03', '0', '2018-08-03 01:56:30');


#
# TABLE STRUCTURE FOR: dues
#

DROP TABLE IF EXISTS `dues`;

CREATE TABLE `dues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `dues` (`id`, `client_id`, `due_amount`, `created_date`) VALUES ('1', '1', '0', '2018-08-02 21:45:32');


#
# TABLE STRUCTURE FOR: gate_pass
#

DROP TABLE IF EXISTS `gate_pass`;

CREATE TABLE `gate_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `in_time` varchar(250) NOT NULL,
  `out_time` varchar(250) NOT NULL,
  `client_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('1', '1', '2018-07-31', '05:00 AM', '00:00 AM', '1', '1', '1', '7', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('2', '2', '2018-07-30', '06:00 AM', '00:00 AM', '1', '1', '2', '5', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('3', '3', '2018-07-29', '03:00 AM', '00:00 AM', '1', '1', '3', '8', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('4', '4', '2018-07-31', '02:00 AM', '00:00 AM', '1', '1', '7', '7', '1', '0', '2018-08-03', '2018-08-02 21:45:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('5', '968', '2018-08-01', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:31:45');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('6', '964', '2018-08-01', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:32:24');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('7', '977', '2018-08-01', '00:00 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-03', '2018-08-03 01:32:56');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('8', '989', '2018-08-01', '00:00 AM', '00:00 AM', '4', '4', '3', '22', '0', '', '2018-08-03', '2018-08-03 01:33:32');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('9', '1000', '2018-08-01', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2018-08-03', '2018-08-03 02:16:01');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('10', '10', '2018-08-01', '00:00 AM', '00:00 AM', '5', '5', '7', '22', '0', '', '2018-08-03', '2018-08-03 01:34:10');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('11', '11', '2018-08-01', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:34:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('12', '12', '2018-08-01', '00:00 AM', '00:00 AM', '7', '7', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:35:07');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('13', '13', '2018-08-01', '00:00 AM', '00:00 AM', '3', '3', '2', '22', '0', '', '2018-08-03', '2018-08-03 01:35:33');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('14', '14', '2018-08-01', '00:00 AM', '00:00 AM', '8', '8', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:36:22');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('15', '15', '2018-08-01', '00:00 AM', '00:00 AM', '9', '9', '5', '22', '0', '', '2018-08-03', '2018-08-03 01:36:52');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('16', '16', '2018-08-01', '00:00 AM', '00:00 AM', '5', '5', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:37:20');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('17', '22', '2018-08-02', '00:00 AM', '00:00 AM', '10', '10', '3', '22', '0', '', '2018-08-03', '2018-08-03 01:38:48');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('18', '34', '2018-08-02', '00:00 AM', '00:00 AM', '4', '4', '2', '22', '0', '', '2018-08-03', '2018-08-03 01:39:38');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('19', '38', '2018-08-02', '00:00 AM', '00:00 AM', '6', '6', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:40:41');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('20', '42', '2018-08-02', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:41:57');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('21', '45', '2018-08-02', '00:00 AM', '00:00 AM', '5', '5', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:42:37');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('22', '49', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '7', '22', '0', '', '2018-08-03', '2018-08-03 01:45:15');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('23', '50', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:46:21');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('24', '51', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '1', '22', '0', '', '2018-08-03', '2018-08-03 01:47:17');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('25', '52', '2018-08-02', '00:00 AM', '00:00 AM', '11', '11', '3', '22', '0', '', '2018-08-03', '2018-08-03 01:48:40');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('26', '53', '2018-08-02', '00:00 AM', '00:00 AM', '12', '12', '5', '22', '0', '', '2018-08-03', '2018-08-03 02:04:29');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('27', '60', '2018-08-03', '00:00 AM', '00:00 AM', '4', '4', '1', '22', '0', '', '2018-08-03', '2018-08-03 02:06:03');
INSERT INTO `gate_pass` (`id`, `serial_no`, `date`, `in_time`, `out_time`, `client_id`, `vehicle_id`, `material_id`, `quantity`, `bill_id`, `amount`, `entry_date`, `date_time`) VALUES ('28', '59', '2018-08-03', '00:00 AM', '00:00 AM', '2', '2', '1', '22', '0', '', '2018-08-03', '2018-08-03 02:07:59');


#
# TABLE STRUCTURE FOR: materials
#

DROP TABLE IF EXISTS `materials`;

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('1', '20 MM', '2018-07-24', '0', '2018-07-31 10:25:28');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('2', '10 MM', '2018-07-24', '0', '2018-07-31 10:25:19');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('3', '6 MM', '2018-07-24', '0', '2018-07-31 10:25:10');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('4', '3 shoot', '2018-07-24', '0', '2018-07-31 10:25:43');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('5', 'Dhoola', '2018-07-24', '0', '2018-07-31 10:26:47');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('6', 'M Send', '2018-07-28', '0', '2018-07-31 10:27:00');
INSERT INTO `materials` (`material_id`, `material_name`, `entry_date`, `status`, `date_time`) VALUES ('7', 'Reti', '2018-07-28', '0', '2018-07-31 10:27:11');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(250) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `entry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `email`, `password`, `role`, `created_date`, `name`, `mobile_no`, `description`, `entry_date`) VALUES ('1', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', '2018-07-22 02:11:58', 'Admin', '9098343935', '', '2018-07-20');


#
# TABLE STRUCTURE FOR: vehicles
#

DROP TABLE IF EXISTS `vehicles`;

CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `vehicle_no` varchar(250) NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('1', '1', '324', '2018-08-03', '0', '2018-08-02 21:39:39');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('2', '2', '324', '2018-08-03', '0', '2018-08-02 21:56:44');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('3', '3', '324', '2018-08-03', '0', '2018-08-02 21:59:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('4', '4', '324', '2018-08-03', '0', '2018-08-02 22:21:00');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('5', '5', '324', '2018-08-03', '0', '2018-08-02 22:25:57');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('6', '6', '324', '2018-08-03', '0', '2018-08-02 22:28:14');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('7', '7', '324', '2018-08-03', '0', '2018-08-02 22:30:15');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('8', '8', '324', '2018-08-03', '0', '2018-08-02 22:34:23');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('9', '9', '324', '2018-08-03', '0', '2018-08-02 22:36:34');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('10', '10', '324', '2018-08-03', '0', '2018-08-02 22:40:33');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('11', '11', '324', '2018-08-03', '0', '2018-08-02 22:45:45');
INSERT INTO `vehicles` (`vehicle_id`, `client_id`, `vehicle_no`, `entry_date`, `status`, `date_time`) VALUES ('12', '12', '324', '2018-08-03', '0', '2018-08-03 01:57:03');


